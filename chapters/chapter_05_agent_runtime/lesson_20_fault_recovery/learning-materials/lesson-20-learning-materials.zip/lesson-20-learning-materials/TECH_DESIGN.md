# 第 20 课 · 异步 Run、Worker 接管与过程展示技术方案

需求简报 · [有效 PRD](PRD.md) · 标准模板 · [第 19 课持久运行](TECH_DESIGN.md) · 代码设计

> Feature 984 · 第 20 课工程节点延续 `compass/L19-complete`，Agent 主库升级到 `0010_run_scheduler.py`。

## 需求依据与验收

以 [FR-01～FR-09、BR-01～BR-11、NFR-01～NFR-04 和 AC-01～AC-11](PRD.md) 为准。Worker 通过 Agent 的专用接口领取、续租和推进任务。Session、Run、Outbox、Redis 短期流和 HITL 沿用第 19 课契约。

M6 的前置合同采用第 19 课 2026-11-12 修订版：[双接口与执行生命周期](TECH_DESIGN.md)、数据结构、Redis及 HITL。M5 已负责 202 接单、连接解耦、Message 快照和 Run 续流；M6 增加队列准入、Worker 执行权、自动接管及相应展示。T0 验证前置实现后才进入 M6 开发，不在本课复制一套持久化底座。

## 1. 方案概述

Agent 在 M5 的同一 PostgreSQL 受理事务中增加 job。Worker 经 Agent 专用接口领取、续租和请求推进到下一持久边界；Agent 执行模型、工作流和工具。复用 M5 的 SQL 状态/Outbox、Redis 短期流与 SQL 完整投影，通过同一 AgentResponse v2 向 Chat 展示结果。Worker 失联时，Agent 收回其驱动权，清理对应执行任务，另一 Worker 从有效 Checkpoint 继续。

### 整体架构

```mermaid
flowchart LR
    C["分析 Chat"] --> B["Web BFF"]
    B --> A["Agent Run API"]
    A --> P[("Agent 主库 · Run / job / Outbox / 完整投影")]
    W["独立 Worker"] --> O["Agent 内部领取与推进"]
    O --> P
    O --> E["M3 / M4 / M5 执行与提交"]
    E --> P
    P --> V["M5 Publisher / Projector"]
    V --> R[("Redis 短期 Run 流")]
    R --> V
    V --> P
    R --> S["Run SSE · AgentResponse delta"]
    P --> M["Message JSON · AgentResponse snapshot"]
    S --> B
    M --> B
```

### 关键决策

| 决策                              | 取舍                                                                                                                                                                                         |
| --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 同库队列与状态                    | Queue 只在 Agent 内。提交 Session/Run、消息、命令回执、关键 Outbox 和 job 同事务写入；复用 M5 幂等。课堂以短调度事务执行公平选择，省去独立 Scheduler 和任务 Broker。Redis 继续只承载运行流。 |
| Worker 驱动、Agent 拥有业务执行   | Worker 领任务并通过内部 HTTP 驱动一个个 Step，独立协程发心跳。它持有不透明执行权，业务上下文、SQL 凭据、模型与持久事务都留在 Agent。引入一次内部往返，保留项目应用边界和唯一数据所有者。     |
| 租约负责接管，Checkpoint 决定位置 | 只在有效 Lease、正确 epoch 和 Step 边界下推进。失效先停止旧执行，核对资源和动作效果，再按 M5 最近有效边界接管。重发同一 Step 命令可取回原回执。                                              |
| 复用完整展示投影与短期流          | 在 M5 的公开业务包里增加调度 Timeline；所有读取复用当前权限过滤和 reducer。基线采用确定性旁白、成功边界一次发布完整回答，省去可选模型摘要及新增分段回答分支。                                |

部署保持一个 Agent 执行所有者、一个 PostgreSQL、M5 已引入的一个 Redis，以及两个独立 Worker 进程。M5 的 Agent 所有者锁、Publisher 和 Projector 生命周期继续保留。Worker 扩展的是驱动与调度槽；模型、工具执行仍占用 Agent 资源。Agent 多副本、独立计算 Worker、独立 Scheduler 和租户专属进程池留给实测后的拓扑调整。

## 2. 调度、接管与数据边界

### 新增数据

现有 M5 的 Run、Step、Attempt、Wait、Artifact、Checkpoint、Outbox 与公开投影结构沿用第 19 课。以下是本次新增的所有持久对象。队列只存调度所需标识与状态，实际恢复数据仍由原 Checkpoint 持有。

```mermaid
erDiagram
    AGENT_RUN ||--o| AGENT_RUN_JOB : schedules
    AGENT_TENANT_SCHEDULE ||--o{ AGENT_RUN_JOB : selects
    AGENT_RUN {
        uuid id PK "M5 原 Run"
        uuid execution_epoch "复用M5唯一执行世代 可空"
    }
    AGENT_RUN_JOB {
        uuid run_id PK,FK "唯一调度记录"
        uuid tenant_id FK "租户调度范围"
        text status "任务调度状态"
        timestamptz ready_at "可领取时间 可空"
        timestamptz first_claimed_at "首次领取时间 可空"
        text worker_id "当前 Worker 可空"
        uuid worker_boot_id "Worker进程实例 可空"
        timestamptz lease_expires_at "到期时间 可空"
        int claim_count "有效领取次数"
    }
    AGENT_TENANT_SCHEDULE {
        uuid tenant_id PK "逻辑租户标识"
        timestamptz last_claimed_at "最近获调度时间 可空"
    }
```

图中 Run 只列调度关联字段，完整定义沿用 M5。仅新增 `agent_run_job`、`agent_tenant_schedule` 两张表；后者只保存租户最近获调度时间，配置使用 Agent 受信任的默认值和按 tenant ID 覆盖值，不建配置管理页面或配置表。

- `run_id` 是 job 的主键及 Agent 本库 FK；`tenant_id` 从 Run 的 Session 归属读取，入库时核验，FK 只指向本库 `agent_tenant_schedule`。默认不删除调度记录。`status` 初值 ready，`claim_count` 初值 0 且非负；其余可空字段按图声明。
- `ready` 必须有 `ready_at`；`leased` 必须有 Worker/boot/expiry，且 Run 有 execution_epoch；`reclaiming` 保留原 Worker/boot/expiry 供清理，Run epoch 已撤销。`parked/done` 清空当前租约字段；旧执行权在持久命令和 Attempt 中保留。跨表不变量由同一事务维护。
- 就绪索引 `(tenant_id,ready_at,run_id) WHERE status='ready'`、过期索引 `(lease_expires_at) WHERE status='leased'`；Worker 部分唯一索引覆盖 `leased/reclaiming`，保证同一配置 Worker 槽最多占用一个 Run。占用统计包含 reclaiming，租约到期本身不释放资源。
- 首次提交和控制继续使用 `agent_command` 的作用域/requestId/摘要。内部 advance 扩展 `kind=worker_advance`，复用该表记录派发中与最终回执；规范键、绑定和读取限制见代码设计。job 不重复保存提交键、请求摘要或第二份 execution_epoch。
- 旧 M5 终态直接读取。旧 created/waiting/paused 无 job 时，在首次 Resume 或有效批准的事务中按容量补建；满额返回 429，保留原状态、决定和 requestId 可重试。新版本已受理的 parked job 持有积压位置，批准/恢复无需再次占位。暂停、等待和终态只在实际资源已确认释放后转 parked/done。

### 受理、配额与公平

- 接单沿用 M5 的 `POST /v1/analysis/sessions/submit`。当前授权通过后，复用 `agent_command` 查重，先返回有效旧回执，再检查新接单容量。同键不同命令 409；新 Session/Run、消息、初始投影、Outbox、命令与 job 同事务提交，返回 202 的 sessionId/runId/streamUrl。数据库接收成功后即使进程中断，ready job 仍可领取；Redis 发布依照 M5 补发，领取/派发等待必要投影就绪。
- 初始课堂档为两个 Worker 槽、全局最多 2 个在途执行、每租户最多 1 个在途执行、每租户最多 4 个已受理未结束 Run、全局 12 个。受理上限涵盖队列、执行和已接受的待恢复任务，后者保留再入队位置。等待和暂停在安全边界确认资源释放后立即归还执行槽，其他租户仍可获调度。取消中的实际资源占用直到清理确认。超限返回 429 和可重试提示，拒绝不创建 Run。容量和耗时阈值是课堂档位，待实际负载确认。
- 受理、领取及可能为旧 Run 新增 job 的 Resume/批准共用事务级调度锁。全局锁序为 **调度锁（需要时）→ Session → Run → job → Step/Attempt → Wait/Action**。控制、提交及清理不反向获取调度锁；操作如果可能增加积压，必须从事务起点先取调度锁。Projector 只取 Run 并写其投影，不反向锁 Session。所有事务保持短小，权限、模型、Sandbox 和 Redis 调用在事务外。
- 领取先过滤无容量租户，按 `last_claimed_at NULLS FIRST, tenant_id`，再按 `ready_at,run_id` 选择。逐候选先锁 Session、再锁 Run，使用 `SKIP LOCKED`；跳过争用候选后继续扫描其他有容量租户。拿到 job 后重验状态与容量；成功领取才更新 `last_claimed_at`。仅以数据库当前占用判断，避免并发双领和单租户阻塞其他候选。[PostgreSQL 锁与跳过规则](https://www.postgresql.org/docs/17/sql-select.html)用于这一短事务；[统一加锁顺序](https://www.postgresql.org/docs/17/explicit-locking.html)覆盖 M5/M6 共同写入路径。

### Worker 交互与状态

```mermaid
sequenceDiagram
    participant C as Chat / BFF
    participant A as Agent
    participant D as PostgreSQL
    participant W as Worker
    C->>A: Submit with request ID
    A->>D: M5 submit + job + Outbox 同事务
    A-->>C: 202 and run ID
    W->>A: Claim
    A->>D: Check quota and set Run execution_epoch
    A-->>W: Execution grant
    par While executing
        W->>A: Heartbeat
    and Step advancement
        W->>A: Advance with epoch and step command ID
        A-->>W: Running receipt, repeat same command to poll
        A->>D: Commit outcome + checkpoint + Outbox
        A-->>W: Continue, parked, or done
    end
    C->>A: Stream events after cursor
    A-->>C: M5 Redis stream + SQL projection, AgentResponse v2
```

- job 使用 `ready / leased / reclaiming / parked / done`；Run 保持 M5 的小写状态。首次领取将 created 转 running。Resume/批准事务只把 job 设 ready、保存原 Run 的可恢复状态及控制回执；ready 阶段公开 reasonCode=queued，Chat 显示“等待执行”；清除已满足的 pause 意图，重复新恢复命令按既有状态冲突返回。只有 claim 能授予新 epoch 并转 running。所有 M5 直接创建执行任务的 submit、Resume、审批/外部事件及 v1 适配器均改走此路径。Agent 根据任务回执推进一段执行，禁止这些入口绕过配额自行启动。
- 内部路由统一为 `/internal/runtime/jobs/{claim,heartbeat,advance,release}`。Agent 配置两份独立 Worker 凭据，凭据绑定 workerId；进程启动生成 bootId，绑定本次 grant。grant 含 runId、workerId、bootId、epoch、expiresAt、checkpointNo，不含用户输入或数据源凭据。BFF 用户凭据与 Worker 凭据互不通用。claim 响应丢失后，同一身份/boot 重试返回仍有效的原 grant；不同 boot 等待旧 grant 清理。无任务返回 204 和建议重试间隔。
- 心跳每 3 秒，TTL 15 秒；Agent 监督与 Worker 空队列轮询上界各 1 秒。续租、派发和提交均在取得行锁后读取 PostgreSQL `clock_timestamp()`，比较 `expiry > now`；过期心跳返回 409 `lease_lost`，不复活旧 epoch。心跳只更新 expiry，不增加 Run.version、不写逐次 Outbox。Worker 收到 lease_lost 或无法在本地保守截止前确认续租时停止 advance。租约校验采用[实际当前时间](https://www.postgresql.org/docs/17/functions-datetime.html#FUNCTIONS-DATETIME-CURRENT)，避免事务开始时间在等锁期间保持不变。
- advance 只接收 grant 和 expectedCheckpoint；服务端按 Run/epoch/边界生成稳定内部命令 ID，Worker 持同一命令重试。Agent 先持久登记运行中回执，再启动独立于 HTTP 的单 Run 任务，立即返回 running；同一命令轮询返回 running 或最终 continue/parked/done 回执。每次只推进到下一个可恢复边界，内部 Workflow 子步骤仍按 M5 独立落盘。HTTP 超时不新建 Attempt，不更换命令；原回执带原 grant，旧 grant 只可读自己的已提交回执，新推进仍返回 lease_lost。
- 每次实际模型/工具派发、业务提交及公开 delta 回调都经过当前 epoch/状态门禁。批准后真实效果仍用 M5 演示适配器的独立短事务，按共同锁序复查租约、取消、权限与 Action ID。正常 Worker 退出先停 claim，保持心跳直到有界当前步骤完成或清理收口；release 仅提交释放意图，由 Agent 确认边界和资源后转 ready/parked/done。请求结束不直接清空租约。
- 到期扫描先撤销 Run.execution_epoch、job 转 reclaiming，并保存接管原因和旧 Attempt。进程内监督任务中止对应执行及流写入；接管前等待旧回调排空，已确认输出沿 M5 保存为完整结果或 incomplete，未决写入按 M5 核对。已提交的合法 Outbox 仍可补发，新 epoch 不接收旧回调。资源和外部效果未确认时保留隔离占用；单凭到期不把 job 改 ready。清理确认后才检查 Checkpoint、权限、版本、预算与原 Action 回执，再排队。取消优先收口、人工暂停/等待保持 parked，可安全重试的中断步骤才生成新 Attempt。
- Agent 重启先恢复 M5 所有者锁、Redis/Outbox/投影，关闭 claim/advance。对原 leased/reclaiming job 撤销旧 epoch并核对资源；其余 ready、parked 和 done 保留语义。仅故障中断且满足 M5 恢复条件的 Run 自动进入 ready；显式暂停、未决审批、未知远端效果继续等待。启动复核完成后开放调度。两个 Worker 的接管测试包含真实进程退出；Agent 重启另验所有者和旧回调隔离。

MCP 接管继续使用 M4 的原目录快照和 M5 的配置版本核对规则。凭据按当前授权重新取得，不跨用户复用会话；旧 Attempt 的远端结局未知时保持待核对，禁止因租约过期自动重放 tools/call。批次策略随节点定义恢复，已提交结果继续复用。

## 3. 对话事件与可观测

### HTTP 接口与同一展示协议

- 完整沿用 M5 的 sessions/submit、sessions 列表、sessions/{id}/messages、runs/{id}/events、pause/resume/cancel、decisions 和 artifacts 路由。Get Status 通过 Message `runId` 过滤返回该 Run 的已提交公开状态、结果和恢复信息。新增内部 Worker API、只读运行诊断和租户用量查询；BFF 使用已有同类鉴权、CSRF 和 Schema 校验。v1 `POST /v1/analysis/runs` 继续作为 M5 适配器，内部进入同一 job 队列，保留它自己的断线取消行为；Web 全部使用 v2。
- Message 从 SQL 一致快照返回 `AgentResponse(mode=snapshot)`，Run 从 Redis 返回 `AgentResponse(mode=delta)`。沿用 `message.upsert/message.delta/run.upsert/view.upsert`，复用同一 validator/reducer；调度变化编码为公开 `timeline` 对象及必要 run.upsert，经现有 Outbox/Projector 提交。对象 ID/revision、父子节点和用户展开状态保持 M5 规则。
- 游标使用原 Redis Stream ID 字符串，按两段整数比较；SSE id 为 `runId:seq`。刷新先加载 Message 与 projected_seq，再续接该 Run。终态流过期返回 409 `history_reload_required`，重新加载完整 Message；活跃流丢失返回 410 `stream_data_lost` 并保持 recovery_required；依赖暂不可用返回 503，历史 SQL 读取仍可用。连接 60 秒轮转，权限最长 5 秒复查，慢连接仅断开订阅。M5 的批次投影门禁与流保留规则保持原样。
- 公共流只写通过展示白名单的业务字段，读取 Message、SSE 与重连继续复查当前范围。Retail 摘要允许日期、维度、成功状态和行数，渠道名称按当前数据权限决定；工具正文和私有执行输入留在其原受控记录。既有获准的 Workflow 源码沿 M5 原展示策略，不另扩展权限。旁白使用确定性模板。运维 Worker/租约详情由独立授权查询从 job、命令及 Attempt 关联，不混入用户流。
- 为兼容 M5 的整帧校验，筛选后保留包的 packetId/seq/revision；被隐藏的整个 `view.upsert` 编码为相同身份和 revision 的安全占位对象，去掉详情、只保留可见状态。一个请求的全部流包仍有对应位置，cursors 等于最后包 seq，无需新增纯游标帧。权限变化或视图范围变更后清除旧视图并重载 Message；不可见整个 Run 时直接拒绝。快照和增量共用这套过滤，严格维护有序 delta 和消息 revision。
- 最终回答基线一次提交：同一关键批次包含助手 `message.upsert(status=completed)` 和 `run.upsert(status=completed)`；SQL 完整投影提交后才向用户公开。客户端整帧应用后，看到同一 Run 的完整助手消息与 completed 才自动折叠一次。旁白与工具文本只更新 view 对象。失败/取消沿 M5 保留 incomplete 消息且不当作成功答案；重连与快照使用同一判断。PRD 的 finalAnswer 是该完整答案的业务称谓，v1 适配器继续输出原字段。本期不启用可选分段回答与模型旁白。

### Timeline 与度量

- 调度/接管的必要 Timeline 作为 M5 `public_view` 中独立稳定 ID 的 timeline 对象持久保存，Redis 过期后仍能读取。Run/Step/Attempt/Tool/Workflow 与 modelCallId/Trace 沿用已有字段。Heartbeat 不生成 Timeline。运维查询要求当前 isPlatformAdmin；租户统计要求当前 tenantRole=admin 与有效成员身份，单个工作区授权不开放整个租户统计。Agent 通过 M5 Web 核验接口确认，不接受浏览器指定租户扩大范围。
- 拟新增 `GET /v1/analysis/runs/{id}/timeline` 供平台运维读取该 Run 的安全阶段、时间、原因及关联 ID，通过既有持久 Timeline、内部命令和 Attempt 拼合；返回有类型只读诊断 DTO，按稳定条目 ID 去重，不返回消息正文、工具原文、凭据或 Checkpoint 密文。用户过程仍通过原 Message/Run 接口读取，不新增诊断页面。
- 拟新增 `GET /v1/analysis/runtime/usage`，只返回当前授权租户的限额、ready/leased/reclaiming/parked 数、积压和占用、已结算 token/成本与未知保守占额。租户明细从 job 与 M5 预算/Attempt 聚合，无新计费账本或管理页；预算沿用 M2 StopPolicy 与 M5 Checkpoint，恢复时保留已用额度。未知成本保留 null 和占额，不记作零成本。
- Retry 新建 Attempt，Resume 接续原 Run，Replay 只读历史。记录正常与 Worker Crash、重复投递、超时、取消竞态。恢复成功率以需接管 Run 为分母，受阻项单列且计入总数；排队时间为 Run.created_at 到 job.first_claimed_at，报告按租户 p50/p95/最大值；槽位利用率按 Timeline 的领取到确认释放区间累计除以观察窗×有效容量，清理隔离占用单列。费用与实际效果计数分别报告，外部观测出口失败不影响这些持久查询。

课堂基线设计目标：两个租户、两个真实 Worker，各用 4 个独立 Session 受理任务；夹具在边界保持 A 的积压，再提交额外请求验证 429，B 在可用槽下推进。对无未决远端效果的可恢复夹具，恢复成功率要求全部成功，旧 epoch 新提交和重复业务效果均为 0；另逐项列出未知效果/清理受阻夹具。固定夹具清理上界 2 秒、监督和轮询上界各 1 秒、HTTP 往返与本机抖动总预留 2 秒时，停止心跳到新合法领取目标 ≤21 秒（15+2+1+1+2）；有空闲槽的无故障 B 任务首次领取目标 ≤3 秒（轮询 1 秒+预留 2 秒）。这是待测的本机课堂目标，运行报告记录实际值和失败项，不改变未知效果的阻塞规则，也不作生产 SLA。

## 4. 迁移、发布与回退

归属 **agent/main**，规划 **0009 → 0010**；0009 目前为 M5 待实施版本，实际编码前核对单一 head 和前置交付。拟新增 `apps/agent/migrations/versions/0010_run_scheduler.py`，包含两张调度表、索引和 `agent_command.kind` 的内部 worker_advance 枚举/约束扩展。epoch 继续使用原 Run 字段。同步 ORM、Alembic、受管版本与运行角色授权；Worker 无数据库凭据。生成完整 bootstrap、支持起点到 0010 的升级 SQL 和 manifest，保留已共享 revision 与历史交付。Web、Worker、Retail 无业务库迁移。

发布按「停接并排空 M5 活动执行 → 按 M5 保存主库、Redis 卷与加密材料 → 迁移至 0010 → 发布保留单所有者的 Agent → 启动双 Worker 并确认领取 → 切换 Web」进行。旧 waiting/paused/created 无 job 的状态保留，首次显式恢复走容量准入；升级不自动派发全部遗留 Run。Agent 就绪检查覆盖主库版本、Redis/投影和所有者；Worker 启动日志需区分依赖不可用、空队列和真正领取，进程存活不作为消费验收。

迁移验证空库、0009 含 waiting/completed/created 数据的旧库、SQL 一致性、权限及协调恢复。回退先停接与 Worker，保留 0010 的 Run/job/流；优先用兼容 0010 的构建恢复读取。回到只接受 0009 的构建时恢复对应备份到独立库及隔离 Redis 命名空间/卷，核对 projected_seq、Outbox、原 Action ID 与效果；保留原库和卷。无法核对的活跃流保持 recovery_required。完整 SQL 和增量的实际生成与验收留在实施阶段。

## 5. 实施任务与验证

```diff
+ apps/agent/src/compass_agent/runtime/run_scheduler.py  受理、配额、租约与接管
+ apps/agent/src/compass_agent/api/worker_runs.py  Worker专用鉴权与领取/续租/推进/释放
! apps/agent/src/compass_agent/api/{sessions,runs}.py  复用M5接口，所有可运行入口入队
! apps/agent/src/compass_agent/runtime/{entities,store,checkpoints,hitl}.py  M5前置：原子job、回执与租约约束
! apps/agent/src/compass_agent/runtime/{service,control}.py  M5前置：一次推进边界、停止及回收
! apps/agent/src/compass_agent/runtime/{message_reader,run_events,public_projection,outbox_publisher}.py  M5前置：调度视图、权限与过期epoch门禁
! apps/agent/src/compass_agent/tools/dispatcher.py  每次实际派发复查执行权
! apps/agent/src/compass_agent/{schemas,settings,main}.py  运行 DTO、配置与路由
+ apps/agent/migrations/versions/0010_run_scheduler.py  主库队列增量
! apps/agent/{migrations/env.py,scripts/database.py,db/main/README.md,db/main/sql/}  受管迁移与派生 SQL
! apps/worker/src/compass_worker/main.py  消费者与信号收口
+ apps/worker/src/compass_worker/run_consumer.py  HTTP 驱动与心跳
! apps/worker/{pyproject.toml,README.md}  HTTP 依赖和消费运行说明
! apps/worker/package.json  保持独立lint/typecheck/test入口
! apps/agent/package.json  新真库测试接入test:integration
! apps/web/src/server/http/analysis-run-handler.ts  诊断/用量授权、v1及v2代理
! apps/web/src/server/modules/models/application/authorize.ts  显式诊断/租户统计用途，沿用现有管理员身份
+ apps/web/src/app/api/analysis/ 下对应运行诊断与用量路由  接入已有handler
! apps/web/src/server/analysis-agent-client.ts  HTTP 契约校验和游标
! apps/web/src/client/analysis-run.ts  断线续接和事件去重
! apps/web/src/components/{analysis-composer,analysis-run-turn}.tsx  进度与最终回答
! deploy/compose/compose.yaml  Worker 配置、接管与验证环境
! deploy/README.md  运行与故障演练
! .env.example  分离 Worker 连接与授权配置
! scripts/export-contracts.py  派生M5 v2及新增调度契约
! contracts/ 与 apps/web/src/generated/  只由生成入口更新
! apps/agent/README.md 与 manifest.yml  对齐调度职责与运行入口
! uv.lock  工作区 HTTP 依赖锁定
+ apps/agent/tests/test_run_scheduler_integration.py  配额、重启与有效租约
+ apps/worker/tests/test_run_consumer.py  续租、信号和重复回执
! apps/web/tests/e2e/analysis-composer.spec.ts  重连、权限与折叠
+ docs/adr/0005-async-runtime.md  部署拓扑和扩展触发条件
+ mai-specs/984-lesson-20-production-agent-runtime/test/FAILURE_MATRIX.md  按故障记录实际结果
+ mai-specs/984-lesson-20-production-agent-runtime/IMPLEMENTATION.md  实际交付与运行恢复报告
```

| 任务                            | 顺序   | 验收                                                                                                                                     |
| ------------------------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------- |
| T0 M5 前置接缝核验              | 实施前 | 0009、Session/Run/Checkpoint/HITL、Redis/Outbox/投影、当前授权及v1适配器已实现；确认一次执行边界入口、锁序和已有验收可复跑。当前待交付。 |
| T1 受管迁移、原子受理与租户准入 | T0 后  | AC-01、AC-03、AC-07、AC-09。重复受理、所有控制入口入队、旧Run容量与M5数据兼容。                                                          |
| T2 Worker、租约与恢复           | T1 后  | AC-03～AC-06。实际终止 Worker 并接管，验证重复领取、旧 epoch、超时、取消及动作只执行一次。                                               |
| T3 用户事件与 Chat              | T2 后  | AC-02、AC-08、AC-10、AC-11。注入受限字段，验证实时、历史、撤权及重连，回归 M1 同步路径。                                                 |
| T4 验收报告与部署               | T3 后  | AC-07～AC-09。测两个租户实际延迟、恢复和利用率，形成 Failure Matrix、运行与恢复报告及拓扑 ADR。                                          |

实施验证须运行 Agent、Worker 和 Web 的 lint/typecheck/test，生成并校验网络契约，执行 Agent PostgreSQL 的空库、0009 升级、权限、派生 SQL 和备份恢复，跑真实双 Worker 进程与 Web 浏览器验证。按跨应用规范运行 `pnpm check`、`pnpm build`、相关 Compose profiles 和 smoke。课堂 Lease 档位及延迟由实测确认，当前设计未运行服务或迁移。

针对本次修正补充验收输入：claim 响应丢失后的重试、advance 受理和结果提交各自的断连、等行锁跨越租约到期、过期心跳、批准/Resume/v1 的配额绕过、取消与批准/接管交错、旧 delta 回调与新 epoch 交错、Redis 终态流过期后 Message 重载、M5 的 Session 锁与新调度路径并发。新用例接入已有测试入口，代码和浏览器验收由后续实施执行。本轮只验证文档、链接、设计片段及阅读版。

## 统一执行过程的前置交接

生产展示沿用第 17 课的统一执行节点及 UiExecutionTree，第 18 课补齐真实工具元数据，第 19 课负责统一协议和持久展示。M6 续接沿用 Run/Redis Stream ID 与对象 revision，保留父子关系、并行组和展开状态；最终回答采用本方案第 3 节的完整消息与成功状态判断。

字段真源与本课前置交互见[第 17 课统一执行过程](TECH_DESIGN.md)。本节不改变本课原有工具、存储和生产执行的交付范围。


## 第 20 课 · 调度与用户事件代码设计

[返回技术方案](TECH_DESIGN.md) · 设计评审

以下是拟议接口与伪代码，尚未实现。复用 M5 的 `runtime/store.py`、Checkpoint、HITL、Outbox 与公开投影；HTTP 编解码、ORM 和遥测样板省略。数据库操作都经 Agent，Worker 只消费 HTTP。共同锁序为调度锁（需要时）→ Session → Run → job → Step/Attempt → Wait/Action。

## 1. 执行权与内部推进回执

`api/worker_runs.py` 验证专用凭据，解析配置绑定的 workerId；`runtime/run_scheduler.py` 管理执行权及边界。类型由 Agent 的 DTO 与路由生成，Worker 不导入 Agent 源码。

```python
@dataclass(frozen=True)
class WorkerIdentity:
    worker_id: str  # 从服务凭据解析；不接受正文替换。
    boot_id: UUID   # 每次启动一个值；同一运行过程持续复用。


@dataclass(frozen=True)
class ExecutionGrant:
    run_id: UUID
    worker_id: str
    boot_id: UUID
    epoch: UUID  # 唯一权威值是agent_run.execution_epoch。
    expires_at: datetime
    checkpoint_no: int  # 无检查点统一为0。


@dataclass(frozen=True)
class AdvanceCommand:
    grant: ExecutionGrant
    expected_checkpoint: int


@dataclass(frozen=True)
class AdvanceAck:
    command_id: UUID
    status: Literal["running", "continue", "parked", "done", "interrupted"]
    checkpoint_no: int
    reason_code: str | None
```

advance 的幂等键由服务端计算 `uuid5(worker_advance_namespace, runId + epoch + expectedCheckpoint)`，规范摘要再绑定 workerId、bootId、同一 Run 和 Checkpoint，忽略心跳会更新的 expiresAt；客户端不能用新的 requestId 反复派发同一边界。

复用 `agent_command`，只扩展内部 `kind=worker_advance`。tenant/workspace/actor_user_id 从原 Run 的授权发起人取得，表示这次执行的委托归属；实际执行者另存于内部 `response` 的 grant 元数据。`response` 为有类型、有大小上限的 `{schemaVersion, grant, expectedCheckpoint, state, ack}`；state 先为 running，再单向收口 committed/interrupted。普通用户命令仍保存不可变原回执；只有此内部 kind 允许这一次状态更新。用户 API 拒绝该 kind，任何命令查重同时校验 kind/摘要，Worker 只得到 ack，不能读取其他用户命令。

原 grant 已释放后，可通过相同 Worker 凭据、boot、epoch 与命令内容读取其已提交回执。Run 已产生新 epoch 时，读取旧回执不授予后继执行权。运行中回执遇到旧 epoch 返回 lease_lost；Agent 恢复把未收口旧命令记 interrupted，后继 grant 使用新的命令 ID。

## 2. 原子受理与公平领取

同一实例内 M5 的 submit/Resume/decision/v1 适配器均通过调度入口，禁止这些路径直接启动执行。当前权限、配置和恢复材料预读在锁外完成，事务内重验版本和归属。

```python
def accept(tx, owner, command, current_access):
    require_current_submit_access(current_access, owner)
    tx.lock_dispatch_admission()
    saved = tx.user_command(owner, command.request_id)
    if saved:
        return same_kind_and_input_or_conflict(saved, "submit", command)
    tx.require_backlog_capacity(owner.tenant_id)  # 包含parked和reclaiming。
    session = tx.lock_or_create_session(owner, command.session_id)
    tx.require_no_nonterminal_run(session)
    run = tx.create_m5_submission(session, owner, command)
    tx.insert_ready_job(run.id, tenant_id=owner.tenant_id)
    # Session/Run/消息/初始投影/Outbox/job/用户命令同事务提交。
    return tx.save_submit_receipt(owner, command, run)


def claim(tx, worker):
    tx.require_agent_owner_and_streams_ready()
    tx.lock_dispatch_admission()
    existing = tx.job_for_worker_slot(worker.worker_id)
    if existing:
        session, run = tx.lock_session_then_run(existing.run_id)
        job = tx.lock_job(run.id)
        if job.worker_boot_id != worker.boot_id:
            return NoWork(reason="previous_process_cleanup")
        if job.status == "leased" and job.lease_expires_at > tx.clock_timestamp():
            return grant_from(run, job)  # claim响应丢失，返回原grant。
        return NoWork(reason="reclaim_pending")
    tx.require_global_execution_capacity()  # leased+reclaiming。
    for candidate in tx.fair_ready_candidates():
        # 按租户last_claimed_at、job.ready_at排序，争用候选不挡住后面的租户。
        locked = tx.try_lock_session_then_run(candidate, skip_locked=True)
        if locked is None:
            continue
        session, run = locked
        job = tx.lock_job(run.id)
        now = tx.clock_timestamp()  # 行锁取得后重新读取实际时钟。
        if not job.is_ready(now) or not tx.has_tenant_capacity(job.tenant_id):
            continue
        if not tx.recovery_and_projection_ready(run):
            continue
        run.execution_epoch = uuid4()
        tx.set_running(run)
        tx.lease(job, worker, expires_at=now + timedelta(seconds=15))
        tx.mark_first_claim_and_increment_count(job, now)
        tx.set_tenant_last_claimed(job.tenant_id, now)
        tx.record_scheduling_boundary(session, run, job, "claimed")
        return grant_from(run, job)
    return NoWork()
```

`record_scheduling_boundary` 更新业务版本，并将安全 run/timeline 对象写入 M5 Outbox；后续派发仍等待关键投影完成。领取失败不更新公平排序。跨表 tenant 归属在创建 job 的事务核对；Worker 槽占用另有部分唯一索引兜底。

## 3. 续租、受理推进与提交

校验执行权时同时验证专用身份、boot、Run epoch、leased 状态及数据库当前时间。心跳不改用户控制版本；取消和回收不允许靠心跳恢复执行权。

```python
def require_live_lease(run, job, worker, grant, now):
    require(worker.worker_id == grant.worker_id == job.worker_id, "lease_lost")
    require(worker.boot_id == grant.boot_id == job.worker_boot_id, "lease_lost")
    require(run.id == grant.run_id, "lease_lost")
    require(job.status == "leased", "lease_lost")
    require(run.execution_epoch == grant.epoch, "lease_lost")
    require(job.lease_expires_at > now, "lease_lost")


def heartbeat(tx, worker, grant):
    session, run = tx.lock_session_then_run(grant.run_id)
    job = tx.lock_job(run.id)
    now = tx.clock_timestamp()
    require_live_lease(run, job, worker, grant, now)
    require(run.status == "running", "lease_lost")
    job.lease_expires_at = now + timedelta(seconds=15)
    return grant_from(run, job)


async def advance(worker, command):
    await authz.recheck_run_execution(command.grant.run_id)
    with database.transaction() as tx:
        session, run = tx.lock_session_then_run(command.grant.run_id)
        job = tx.lock_job(run.id)
        key = internal_advance_key(command)
        saved = tx.worker_command(run.owner, key)
        if saved:
            require_same_worker_grant_and_digest(saved, worker, command)
            if saved.state == "committed":
                return saved.ack  # 已提交旧回执可重读；此分支无新写入。
        require_live_lease(run, job, worker, command.grant, tx.clock_timestamp())
        if saved:
            require(saved.state == "running", "command_interrupted")
            return saved.ack  # 暂停意图不妨碍只读轮询正在收口的原命令。
        require(run.status == "running" and run.control_intent is None, "run_not_runnable")
        require((run.checkpoint_no or 0) == command.expected_checkpoint, "checkpoint_conflict")
        saved = tx.prepare_worker_command(run, worker, command, key)
    # 任务map按Run/command去重；任务归lifespan，HTTP结束不取消。
    # 受理提交后尚未启动即崩溃，旧命令由启动回收处理，保持可诊断。
    try:
        tasks.ensure_boundary_task(saved.id, lambda: execute_one_boundary(worker, command))
    except TaskStartError:
        await scheduler.reclaim_unstarted_command(saved.id)
        return interrupted_ack(saved, "execution_start_failed")
    return saved.ack


def commit_advance(tx, worker, command, outcome):
    session, run = tx.lock_session_then_run(command.grant.run_id)
    job = tx.lock_job(run.id)
    saved = tx.worker_command(run.owner, internal_advance_key(command))
    require_same_worker_grant_and_digest(saved, worker, command)
    if saved.state == "committed":
        return saved.ack
    require_live_lease(run, job, worker, command.grant, tx.clock_timestamp())
    require(run.status == "running", "run_not_runnable")
    require((run.checkpoint_no or 0) == command.expected_checkpoint, "checkpoint_conflict")
    result = tx.commit_m5_boundary(session, run, outcome)
    # Outcome由Agent执行器产生，Worker不能上传模型输出、成本或业务结果。
    if result.resources_confirmed and result.waiting_or_paused:
        tx.park_and_clear_epoch(run, job)
    elif result.resources_confirmed and result.terminal:
        tx.finish_job_and_clear_epoch(run, job)
    elif result.resources_unconfirmed:
        tx.revoke_and_reclaim(run, job, reason="cleanup_unconfirmed")
    if result.scheduling_changed:
        # 扩充本事务刚创建、尚未发布的同一Outbox，保留一个run_version。
        tx.append_scheduling_to_boundary(result.outbox_id, run, job)
    return tx.commit_worker_ack(saved, result)
```

`execute_one_boundary` 复用 M5 持久执行器，先在锁外等待前序关键投影；每次模型/工具/动作派发前都经过调度门禁，内部子调用记录原 Step/Attempt。继续、等待或完成的回执与 M5 业务结果、Checkpoint、调度变化和 Outbox 同事务收口。公开调度变化同时记录领取及确认释放，供占用区间统计。对外工具和 Redis 操作全在业务锁外；等待投影完成后才允许下一命令的实际派发。已提交命令回执的只读返回不等待 Redis。

取消或过期后的已返回结果走 Agent 清理/效果核对入口：只按原 Attempt/Action ID 补记结局、费用和清理回执，不覆盖新的 Checkpoint、成功消息或执行权。旧执行者无法调用它来派发新动作。已成功提交的效果保留；未知结果沿用 M5 的保守预算占额。

## 4. 控制接续、回收和 Worker 循环

```python
def resume_or_approve(tx, owner, command, current_access):
    # 可能为旧M5 Run补job，从事务起点取调度锁。
    tx.lock_dispatch_admission()
    session, run = tx.lock_session_then_run(command.run_id)
    job = tx.lock_job_if_present(run.id)
    previous = tx.user_command(owner, command.request_id)
    if previous:
        return same_kind_and_input_or_conflict(previous, command.kind, command)
    tx.validate_m5_control(session, run, command, current_access)
    tx.require_parked_or_legacy_job_for_new_resume(job, command)
    if job is None:
        tx.require_backlog_capacity(session.tenant_id)
        job = tx.insert_parked_job(run.id, session.tenant_id)
    ack = tx.apply_m5_decision_without_starting_executor(session, run, command)
    if ack.can_resume:
        tx.require_current_resources_settled(run)
        tx.clear_satisfied_control_intent(run)
        run.reason_code = "queued"
        tx.make_ready(job)  # 保留waiting/paused，claim时才转running和授予epoch。
    elif ack.terminal:
        tx.finish_job_and_clear_epoch(run, job)
    tx.record_control_outbox(session, run, ack)
    return tx.save_user_command_receipt(owner, command, ack)


async def reclaim(run_id):
    with database.transaction() as tx:
        session, run = tx.lock_session_then_run(run_id)
        job = tx.lock_job(run_id)
        now = tx.clock_timestamp()
        if job.status == "leased" and job.lease_expires_at <= now:
            tx.revoke_and_reclaim(run, job, reason="lease_expired")
        if job.status != "reclaiming":
            return
    # 撤权先提交；执行句柄、旧流回调与效果核对在锁外完成。
    receipt = await execution.stop_and_reconcile_original_attempts(run_id)
    with database.transaction() as tx:
        session, run = tx.lock_session_then_run(run_id)
        job = tx.lock_job(run_id)
        require(job.status == "reclaiming", "recovery_conflict")
        tx.record_cleanup_receipt(run, receipt)
        if not receipt.resources_confirmed:
            tx.mark_recovery_blocked(run, receipt.reason)  # 仍占槽。
        elif run.status == "cancelling":
            tx.finish_canceled_if_effects_reconciled(run, job, receipt)
        elif run.control_intent == "pause" or tx.has_pending_wait(run):
            tx.park_and_clear_epoch(run, job)
        elif tx.safe_checkpoint_and_effects_confirmed(run, receipt):
            tx.interrupt_unfinished_worker_commands(run)
            tx.make_ready_and_clear_lease(job)
        else:
            tx.park_recovery_blocked(run, job, receipt.reason)
        tx.record_recovery_outbox(session, run, job)
```

取消事务复用 Session/Run/job 的锁顺序，先保存 cancelling 并撤销新派发许可。未领取且无资源的任务直接取消；在途任务转 reclaiming，清理/效果核对后才 done。批准与取消、claim 与取消按同一行锁裁决。暂停只在安全边界停下；已接受的当前步骤可以收口，后继派发须检查 pause 意图。

Worker 每个进程只有一个配置槽。启动后生成 bootId；claim 无任务按 1 秒上界退避。拿到 grant 后并行运行心跳和 advance 轮询：同一边界一直使用相同命令；continue 才换 expectedCheckpoint；parked/done 结束本轮。心跳确认使用“发送时本地单调时钟 + TTL”作为保守截止，HTTP 超时按原命令重试；lease_lost、截止或取消意图立即停止新 advance。SIGTERM 停止 claim、请求 release，当前任务在有界清理内续租；超时退出由 Agent 继续回收。

Agent 启动恢复先持有 M5 单执行所有者锁并补齐流和投影，再对旧 leased/reclaiming 撤权核对。持久命令 running 但没有本地任务的情况通过这个恢复入口处理。用户 waiting/paused、未知远端效果及显式暂停保留原控制语义。

## 5. M5 公共协议扩展与最终回答

保留 M5 `AgentResponse/AgentPacket/AgentEvent` 唯一联合，沿用 `runtime/public_projection.py` 和 `runtime/run_events.py`，不再新增第二个投影服务。调度事件转换为有类型 Timeline 对象，私有 Worker 身份留在内部回执。

```python
def scheduling_view(run, job, transition_id, reason, occurred_at):
    return ViewUpsert(
        object_id=f"timeline:{transition_id}", revision=1, kind="timeline",
        value=PublicTimelineEntry(
            run_id=run.id, phase="scheduling", status=job.status,
            reason_code=public_reason(reason), claim_count=job.claim_count,
            occurred_at=occurred_at,
        ),
    )


def filter_public_response(body, access):
    require_owned_session_and_runs(body, access)
    packets = []
    for packet in body.packets:
        # snapshot/delta调用同一函数，保留身份、seq和revision。
        if packet.event.type == "view.upsert":
            event = allowlisted_view_or_safe_placeholder(packet.event, access)
        else:
            event = require_visible_message_or_run(packet.event, access)
        packets.append(packet.with_event(event))
    return body.with_packets(packets)
```

`allowlisted_view_or_safe_placeholder` 复用原对象类型，只替换该 DTO 支持的安全标题/状态并去掉全部受限详情；对象本身不允许最低展示时拒绝对应 Run 读取。Message 正文当前权限不足时同样拒绝，避免删掉某个 message.delta 破坏后续 revision。不存在新的 cursor-only 包；整帧最后一个 seq 仍与外层 cursor 一致。授权范围变更时通过重新加载 Message 清除旧详情，所有预览均按同一白名单生成。

```typescript
function applyScheduledResponse(state: SessionView, response: unknown): SessionView {
  const next = applyAgentResponse(state, response); // M5：整帧校验与原子应用。
  for (const run of next.runs) {
    const answer = next.completedAssistantMessage(run.id);
    const completed = run.status === "completed" && answer !== undefined;
    if (completed && !next.answerTransitionSeen.has(run.id)) {
      next.answerTransitionSeen.add(run.id);
      // 用户显式展开优先，重复快照与旧事件不改变这一选择。
      if (!next.userProcessPreference.has(run.id)) next.collapseProcess(run.id);
    }
  }
  return next;
}
```

一次成功边界发布完整 message.upsert 和 completed run.upsert。两者完成 SQL 投影后才可见；工具旁白只影响 view 对象。失败/取消的 incomplete 消息不触发成功切换。Stream ID 比较、重连、409 历史重载与 410 活跃流丢失直接使用 M5 逻辑。

## 6. 必要验证

实施时验证：重复 submit/claim/advance、等锁跨越 TTL、过期心跳、boot 更换、所有恢复入口的配额、锁序争用、取消与效果写入、旧 delta 回调、真实双 Worker 接管、Agent 重启、Redis 过期后的完整 Message 与回答折叠。并核对每个租户占用、未知成本和本机恢复时间。这里的片段是设计示意，运行结果待实施阶段获取。


## 第 20 课故障矩阵

返回需求简报 · 业务测试计划 · [有效 PRD](PRD.md)

2026-11-12，故障验收执行版。以下触发点和不变量依据已评审 [TECH_DESIGN](TECH_DESIGN.md) 与 CODE_DESIGN。FM-00～FM-23 均已完成对应层次的当前验证；真实 Worker 强杀、Agent 强杀、在途 SIGTERM、未确认效果、权限变化与观测失败分别登记。实际入口、测试夹具范围、首轮问题和最终复验见 执行记录。

## 共同验收不变量

- 一个已受理 Run 只保留一个 job；只有当前有效 workerId/bootId/epoch、未过期 Lease 与合法状态可推进。
- 重复 submit/claim/advance 和网络丢响应保持原回执语义；已经提交的分析结果和可核对 Action 效果复用。
- 取消受理后新业务动作数为 0；旧 epoch 的新 Checkpoint、成功结果及公开增量提交数为 0。
- leased/reclaiming 都占执行槽，实际资源/远端效果确认后才释放；未知效果/成本保留恢复说明与保守占额。
- 公开 Message 与 SSE 使用同一权限过滤、完整业务投影与 AgentResponse v2；原 Run 的历史可读且重复加载不派发。

## 正常基线与故障样本

| ID    | 类别与关联                         | 触发点 / 实际操作计划                                                                | 必须核对的结果                                                                 | 记录要求                                             | 当前状态 / 实际结果                              |
| ----- | ---------------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ | ---------------------------------------------------- | ------------------------------------------------ |
| FM-00 | 正常基线；TC-01/04/12/17           | 两租户各 4 个 Session、双真实 Worker；含普通分析和审批任务                           | 配额、成功答案、等待释放、再入队；排队与利用率基线                             | 两 Worker PID/boot、全部 Run、usage、Timeline、回答  | 通过：双租户 8 轮；审批真实 UI 通过              |
| FM-01 | 持久接收中断；TC-02                | Session/Run/job/命令/Outbox 事务提交后、首次领取前终止 Agent；另在事务提交前注入失败 | 提交后原 Run 可补交付；提交前完整回滚；重复 requestId 返回原结果或正常首次受理 | 提交屏障、重启 PID、记录数和外部调用数               | 通过：M6 原子受理/启动复核，M5 持久交付故障      |
| FM-02 | 重复投递；TC-05                    | 并发 claim 同一就绪 Run、同一槽；丢弃已提交 claim 回执并重试                         | 同 boot 原 grant/epoch/claim_count；唯一有效领取和槽位占用                     | 原/重试 grant、claim_count、调用审计                 | 集成通过：并发领取、同 boot 原回执               |
| FM-03 | 进程身份更换；TC-05                | 原 workerId 的新 boot 尝试 claim/heartbeat/advance；互换凭据或伪造正文身份           | 原占用先清理；boot/凭据/Run 归属不匹配拒绝，用户/Worker 凭据分离               | 身份摘要、状态码、安全载荷、job                      | 通过：HTTP 凭据、boot 和槽位约束                 |
| FM-04 | advance 受理丢响应；TC-06          | running 命令提交后 HTTP 断开；持续重发相同边界，途中正常续租                         | 一个内部命令/执行段；expiresAt 不改变身份；HTTP 断开保留任务                   | commandId、expectedCheckpoint、Attempt/实际调用数    | 通过：M6 HTTP 同边界轮询，M5 实际断连            |
| FM-05 | advance 提交丢响应；TC-06          | 结果/Checkpoint/回执已提交后丢弃响应；释放 grant 后再读旧命令并尝试新边界            | 原提交回执可读；已提交结果复用；旧 grant 无新推进权                            | 原回执、Checkpoint、Outbox、后继拒绝                 | 集成通过：旧提交回执与后继推进拒绝               |
| FM-06 | Lease 超时；TC-07                  | heartbeat、派发、提交等锁跨越 TTL，锁释放后继续；另发过期 heartbeat                  | 锁后真实数据库时刻裁决，lease_lost；无复活、无迟到新写入                       | 锁/时刻/expiry、接口回执、版本/事件差分              | 通过：真实 PG 等锁跨 TTL，三个入口               |
| FM-07 | Worker Crash；TC-08                | 真实 Worker 1 在已提交步骤后被终止；Worker 2 继续消费                                | 同 Run 新 epoch，从 Checkpoint 接续；已完成调用不重复，受控接管 ≤21 秒         | 退出 PID、最后心跳、清理及新 claim 时刻、效果/调用数 | 通过：3 次 SIGKILL，最大 18.605460 秒            |
| FM-08 | Crash 与动作效果窗口；TC-08/10     | 真实效果已提交、原执行回执尚未完成时停止 Worker/执行驱动                             | 稳定 Action ID 核对并复用效果；实际效果总数一次                                | 外部账本、Action/Attempt、两 grant、终态             | 通过：M6 效果核对、未知阻断，M5 实际效果后退出   |
| FM-09 | 旧结果/delta 迟到；TC-07           | 保持旧回调到新 epoch 建立后放行                                                      | 新 Checkpoint/消息/增量保持；旧已提交 Outbox 可补发，有限结局核对单列          | 回调 epoch、完整 SSE/Message、Checkpoint、费用       | 通过：旧 epoch 边界/PG 迟到 progress 拒绝        |
| FM-10 | 执行超时；TC-09                    | 无副作用模型/工具夹具超过配置期限，覆盖允许重试与预算不足                            | 有明确超时原因；Retry 按策略产生新 Attempt；预算与占用连续，终态受控           | 配置期限、每 Attempt、StopPolicy、usage              | 通过：真实模型 1 秒超时及工具预算耗尽            |
| FM-11 | 未知远端效果；TC-09                | MCP 写已派发但远端响应丢失，随后 Lease 到期                                          | 不自动重放 tools/call；恢复受阻、原 Action 与未知成本占额保留                  | 进程外效果/调用数、recovery reason、预算             | 通过：独立 HTTP 效果一次，保守阻断               |
| FM-12 | 清理未确认；TC-09/10               | Sandbox/工具清理无法确认并触发到期或取消                                             | reclaiming 保留槽位；新 claim 不越过实际容量；可用其他槽正常服务               | 清理回执、资源状态、usage、另一租户 Run              | 通过：未确认清理集成与真实未知效果占额           |
| FM-13 | 取消与动作竞态；TC-10              | 取消先/动作发起先、效果已提交后取消分别执行                                          | 受理取消后零新动作；先前合法效果保留；唯一终态与确认释放                       | 取消和动作时间、Action 账本、Run/Timeline            | 通过：M6 零后继派发，M5 效果/取消竞争            |
| FM-14 | 取消与接管竞态；TC-10              | 取消先/claim 先两序；迟到旧 grant 与重复投递                                         | 取消收口优先，终态不复活，旧 epoch 零新推进                                    | 两顺序屏障、grant、状态/占用差分                     | 通过：M6 领取前后取消先后，旧 grant 拒绝         |
| FM-15 | 批准与取消/重复竞态；TC-03/04/10   | 有效批准和取消交错、重复批准、满额时批准旧 M5 无 job Run                             | 一次有效决定；取消后无新效果；满额原 Wait/请求键可重试，全部接续排队           | Wait/Action/命令、429/回执、job、外部效果            | 通过：M6 入队/背压，M5 批准与取消/到期并发       |
| FM-16 | Agent Crash 与启动复核；TC-11      | 存在 leased/reclaiming/running 命令时真实重启 Agent                                  | 恢复底座前关 claim/advance；旧 epoch 撤销；安全任务再入队，显式暂停/等待保留   | 所有者/流/投影就绪、旧命令结局、各类 Run             | 通过：M6 Agent 强杀重启、原 Checkpoint/暂停记录保留          |
| FM-17 | Worker SIGTERM；TC-11              | 运行中正常终止 Worker，覆盖短步骤与清理延迟                                          | 停止新 claim；有界收口、允许的心跳与 release 意图；退出后清理占用正确          | 进程退出码、请求日志、释放区间/资源计数              | 通过：真实在途 SIGTERM 1.371713 秒正常退出、单次 release               |
| FM-18 | 容量与公平；TC-12                  | A 满执行/积压并持续超额、A 候选 Session 持锁，B 空闲容量；另触发全局上限             | 429 无新 Run；A≤1/全局≤2 在途；B 不被争用候选阻塞，无故障首领 ≤3 秒            | 各租户队列/用量、p50/p95/max、拒绝计数               | 通过：双租户、配额、跳锁与 B 2.111228 秒         |
| FM-19 | SSE 断线与流失效；TC-13            | 真断线续游标、终态流过期、活跃流丢失、Redis 暂不可用                                 | 按序无重复；409 重载、410 恢复受阻、503 安全反馈；SQL 历史可读，无新增执行     | 实际状态码/游标、完整帧与快照、浏览器请求次数        | 通过：实际断连、AOF/流丢失/Redis 故障与重放      |
| FM-20 | 撤权/展示范围变化；TC-14/15        | 注入受限标记，实时与历史读取；流中撤权并重连                                         | 载荷/DOM 无受限字段；安全占位保留 seq/revision；当前权限阻断/清除旧详情        | 脱敏扫描结果、帧校验、旧连接关闭时刻、角色矩阵       | 通过：4 项真库流复查、权限矩阵及 UI 过滤         |
| FM-21 | 回答前后断线、失败和取消；TC-17/18 | 旁白含“最终回答”；成功批次前后断线、重复帧、手动展开；部分答案失败/取消              | 仅结构化成功切换、自动折叠一次、用户偏好保持；未提交答案为 incomplete          | 真实 UI/焦点、Frame/Message、下一轮模型历史          | 通过：9 UI、2 真实完成、M5 竞争与历史            |
| FM-22 | 观测出口不可用；TC-16              | 实际模型/Workflow Run 执行中关闭测试观测出口，重复历史查询                           | 持久 Timeline/状态/用量可读；Retry/Resume/Replay 关联明确，历史无新调用        | modelCallId/Trace、Timeline、调用数、安全字段        | 通过：运行在途出口失败，完成后历史/Timeline 可读 |
| FM-23 | 迁移与恢复；TC-20                  | 空库、0009 有数据旧库原生/SQL 升级，独立库+隔离 Redis 备份恢复                       | 单一 head、原数据/Action/文件保留；旧无 job 不自动派发，恢复一致且原库/卷保留  | schema/角色/SQL manifest、原记录及恢复读取           | 通过：数据库 22 项及 M6 native/SQL 升级          |

## 实际结果追加格式

每次故障执行追加：日期与源码范围、隔离环境、实际入口及退出码、故障触发屏障、原/新进程与 Worker 身份、Session/Run/Action、实际不变量观察、量化值、原始记录路径和当前结果。敏感凭据只登记引用。

恢复指标按测试计划度量口径计算。可恢复样本、未知效果受阻样本、清理占用样本分组展示，恢复总分母保留所有需接管 Run。一次故障的重复执行不重复增加样本数；明确使用不同 Run 的独立实验可单独计数。

四类课堂必测为 Worker Crash（FM-07/08）、重复投递（FM-02/04/05）、超时（FM-06/10/11/12）、取消竞态（FM-13/14/15）。必要场景未执行、失败或受阻时保留当前状态，报告只对实际完成的范围给结论。

## 独立 Worker / UI 已验证子项

本节记录已执行范围；完整故障触发和业务效果仍由上表对应实验核对。

| 对应 FM              | 本轮已通过范围                                                                                                 | 执行结果及仍待核对范围                                                  |
| -------------------- | -------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| FM-00/15             | 两真实 Worker 已运行；单租户周报完成、预算 waiting 释放执行槽，批准后同 Run 二次入队完成                       | 真实浏览器 2/2；未在此轮模拟批准/取消竞争，双租户公平另由进程任务交接   |
| FM-02/03/04/05/06/17 | MockTransport 验证 claim 身份、同边界重试、expiresAt 不改变边界、迟到心跳不复活、信号边界 release              | Worker 27/27；包括自建进程 SIGINT/SIGTERM，未据此标记真实服务端故障完成 |
| FM-19                | queued 断线重连 UI；两个真实完成 Run 从 0-0 重放与 Message 一致，重复帧幂等，刷新无新命令                      | 通过：实际断连、AOF/流丢失/Redis 故障与重放                             |
| FM-20                | 安全快照替换旧详情；BFF 当前权限矩阵；真实租户 usage 与平台 Timeline 权限分离；公开 Message 无 Worker 私有字段 | 通过：4 项真库流复查、权限矩阵及 UI 过滤                                |
| FM-21                | 可控成功/失败/取消、旁白、重复帧、自动折叠/用户展开偏好/键盘焦点；真实周报与预算完成后折叠和历史刷新           | 通过：9 UI、2 真实完成、M5 竞争与历史                                   |

实际入口、首轮问题及复验详见 执行记录。真实 Run 为 `9ab380fd-c9de-437f-9477-184693b6462c`（周报）和 `21dfd5cf-ea68-44d9-b5c8-3384f9b818a4`（预算）。原始业务输出为 `work/lesson-20/runtime-live-current-business.json`；Worker/单测/UI 日志均保存在 `work/lesson-20/`。

## 独立进程故障执行结果

独立任务已交接 `work/lesson-20/process-test.log` 与 `process-acceptance.json`：真实 Agent/PG/Redis、两个真实 Worker、独立 HTTP 效果服务，1 项复合实验通过，137.27 秒。配置为 heartbeat 3 秒、TTL 15 秒、租户容量 1、全局容量 2。

- FM-00/18：两租户各 4 个独立 Session 全部完成，A 第 5 次提交返回 429 且无额外 Run。B 首领 2.111228 秒；1523 次采样峰值为全局 2、每租户 1。A 排队 n=4、p50=6.055861 秒、p95/max=16.166829 秒；B n=4、p50=6.048310 秒、p95/max=16.183484 秒。
- FM-07/09：三个真实 SIGKILL 后均由不同 Worker/新 epoch 在 Checkpoint 1 接续，原已提交 Attempt 保留；最后心跳至新领取分别 18.605460、17.564396、15.717994 秒。物理 sum/double 各一次，最终 Message 380；旧 heartbeat/advance 为 409，迟到推进为 0。
- FM-08/11/12：未知样本的外部 HTTP 效果总数 1；无回执 Attempt 保留 dispatched 与空 output，Run blocked、job reclaiming、epoch 已撤销。A 的后继仍 ready/未领取，B 使用另一槽完成，A 的 usage occupied=1。
- 恢复样本总数 4，恢复 3、未知受阻 1；安全子集 3/3，总体恢复率 3/4。接管 n=3、p50=17.564396 秒、p95/max=18.605460 秒，满足 21 秒目标。全部样本均保留在分母。
- 48 个调度事件，观察窗口 126.483661 秒，容量分母 252.967322 slot·s；占用 130.553087 slot·s，利用率 51.6087%，其中 reclaiming 9.606331 slot·s。该进程夹具未调用模型，模型 token/费用为 0；预算与超时另由后续测试交接。

Run/PID、旧新 grant、原 Attempt、独立效果审计和逐次采样保存在 JSON；概要及三个 Run 逐项数据见 执行记录。

## 流中当前权限实验

`test_runtime_visibility_integration.py` 使用真实 PG/Redis 和生产 SSE/Message 入口，当前授权 callback 分别切换 forbidden、authorization_unavailable、仅 revision 变化、details 收紧。四项 4/4 通过，原连接分别在 5.081、5.075、5.087、5.093 秒关闭；后续请求执行最新权限，安全重投影保持原 packet/seq/object/revision/cursor，原持久内容与 Run.version 不变。记录为 `work/lesson-20/runtime-visibility-integration-retest.log`，关闭计时从授权回执变化开始。

## 超时、预算与观测故障补充

- FM-10/11：`test_run_scheduler_limits.py` 2/2 通过，10.69 秒。工具预算跨 4 个 Checkpoint 后以 budget_exhausted/max_tool_calls 收口，实际 SQL 1 次、模型夹具 2 次，partial 保留；模型服务实际 3 秒上游对 1 秒期限触发 model_timeout，仅 1 次物理请求，保守占额 192 tokens/768 microusd。两例 job done、occupied=0，后继任务均完成。记录为 `limits-test.log` / `limits-acceptance.json`。
- FM-22：同一实际 M6 Run 的物理计算在途时，Observer 出口被设为失败；失败期间原 Run 完成，Trace ID、Message、SSE 与平台 Timeline 可读。实际出口失败 3 次，物理计算 1 次，Timeline 8 条；历史/Replay 不增 command/Attempt/物理调用，无权主体拒绝。与四项权限变化组合运行最终 5/5 通过，32.45 秒，见 `runtime-visibility-observability-final.log`。
- 本轮 M5 durable core 18 项及 faults/cases/boundaries 13 项通过；补齐真实 Redis AOF/OOM/owner loss、实际进程退出、效果窗口、批准/取消/到期并发、ModelService Retry/Trace 和 QuickJS host 退出。M5 夹具保持原执行路径；M6 调度层通过新 30 项集成、readiness gate、limits 和真实 Worker 进程验证。对应日志和分层映射见 执行记录。
