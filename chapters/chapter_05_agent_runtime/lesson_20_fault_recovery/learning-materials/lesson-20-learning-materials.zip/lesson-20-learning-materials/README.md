# 第 20 课学习资料

《企业级Agent工程架构实战营》 · 从单进程到企业级 Runtime：实现异步调度、资源治理与可靠性验证

解压后双击 [TECH_DESIGN.html](TECH_DESIGN.html) 离线阅读。

- [PRD.md](PRD.md) 收录需求、业务规则和验收标准。
- [TECH_DESIGN.md](TECH_DESIGN.md) 收录技术正文与配套设计。
