# 第 15 课｜从 LLM Runtime 到 Agent Runtime：搭建 Agent 执行内核

《企业级Agent工程架构实战营》第五篇学习资料。解压后在浏览器打开 [技术方案 HTML](TECH_DESIGN.html)，可离线阅读图表和代码。

- [PRD](PRD.md) 包含功能范围、业务规则与 AC-01 至 AC-15。
- [Markdown 技术方案](TECH_DESIGN.md) 包含类型设计、运行链路、终止清理和实现取舍。

课堂数据采用登记的 Retail 样本及对应发布工具。真实供应商和数据库环境的历史验收见工程实施记录。生产负载仍需独立验证。
