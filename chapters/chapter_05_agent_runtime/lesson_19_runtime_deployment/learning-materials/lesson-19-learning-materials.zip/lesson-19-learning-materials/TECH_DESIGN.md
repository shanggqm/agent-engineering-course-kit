# 第 19 课 · 完整运行持久化与 Message / Run 统一协议

> Feature 985 · Profile `standard` · 第 19 课独立工程节点以 `compass/L18-complete` 为基线，Agent 主库迁移到 `0009_durable_runs.py`。

需求简报 · [有效 PRD](PRD.md) · 标准模板 · 完整数据设计 · Redis 与本地部署 · 代码设计 · HITL 增量方案 · [HTML 审阅版](TECH_DESIGN.html)

## 1. 目标与设计边界

本方案负责 PRD FR-01～FR-03、FR-07～FR-16 的持久化主线；HITL 增量方案负责 FR-04～FR-06 及控制竞态。共同满足 AC-01～AC-19，验收编号只在 PRD 维护。

目标路径是：问一次便有持久 Session，前序案例执行后刷新能从左侧打开原会话，恢复相同的消息、过程和结果；执行中断线可继续订阅，服务重启可读取完整历史并显式接续有效边界。内容读取采用 Message 非流式接口和 Run 流式接口，响应共用 AgentResponse、一套业务包 Schema 和同一个 reducer。

当前复用与补齐：

| 对象/现状入口                                                             | 现状                                                                  | 本课处理                                                            |
| ------------------------------------------------------------------------- | --------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `apps/web/src/components/shell/app-shell.tsx`                             | 会话列表空占位                                                        | 加载 Agent 所有的 Session 元数据，稳定会话地址和分页                |
| `apps/web/src/components/analysis-composer.tsx`、`client/analysis-run.ts` | `turns` 内存，浏览器选择历史后随请求发送                              | Message加载与Run增量驱动同一视图；追问历史由服务端组装              |
| `runtime/control.py`、`api/runs.py`                                       | Registry 和终态摘要在内存；断线取消执行                               | 数据库管理业务状态；进程管理执行句柄；订阅关闭不取消 Run            |
| `harness/context.py`、`harness/controlled_run.py` 及计划/Verifier 模块    | 消息、计划、证据和预算在内存                                          | 消息实体、步骤结果、版本化 Checkpoint                               |
| `runtime/execution_trace.py`、`stream.py`                                 | 临时节点、序号、实时编码                                              | 稳定节点与展示投影；Run 增量与 Message 完整内容包共用协议           |
| `models/entities.py`、`llm/executor.py`                                   | `model_call` 有元记录和收口后的 execution 摘要；中途 Attempt 尚在内存 | 保留原表，增加关联和必要内容引用；真实 Attempt 派发前登记、逐次保存 |
| `workflows/assets.py`、`workflows/drafts.py`、`workflows/script.py`       | 已保存资产入库；草稿、QuickJS 位置和子调用在内存                      | 复用资产；持久草稿、冻结脚本、步骤日志和已完成子结果                |
| M4 的 `tools/` 目标模块                                                   | 0008 已有配置/分配迁移；运行目录、结果与产物仍需运行级提交            | 复用配置/分配，补每 Run 目录、调用记录、产物字节与恢复关系          |

M4 的 `api/runtime/harness/workflows/tools` 拆分源码已存在；实施核对[前置迁移映射](TECH_DESIGN.md)与当前工作区一致。本课新增长期存储、单实例执行和人工确认。

### 整体架构

```mermaid
flowchart TB
    UI["Session / AnalysisComposer"] --> BFF["Web BFF · 身份与响应 Schema"]
    BFF --> CMD["提交与控制命令"]
    BFF --> MSG["Message API · application/json"]
    BFF --> RUN["Run API · text/event-stream"]
    CMD --> RT["RunService · 独立执行任务"]
    RT --> H["Harness / Workflow / Tool / LLM"]
    H --> STORE["Runtime Store · 关键业务事务"]
    STORE --> DB[("PostgreSQL · 业务状态 / Checkpoint / Outbox / 展示投影")]
    DB --> PUB["Outbox Publisher · 关键变化补发"]
    H --> DELTA["合并文本增量"]
    PUB --> LOG[("Docker Redis Streams · AOF always")]
    DELTA --> LOG
    LOG --> PROJ["Projector · 定时合并 / 关键边界强制提交"]
    PROJ --> DB
    DB --> MSG
    LOG --> GATE["持久确认 / 关键包投影门禁"]
    DB --> GATE
    GATE --> RUN
    MSG --> RESPONSE["同一 AgentResponse"]
    RUN --> RESPONSE
    RESPONSE --> RED["同一 validator / reducer / 组件"]
```

- PostgreSQL 业务存储归 `agent/main`；Redis 运行流由 Agent 独占读写。Web 通过 HTTP 访问，Memory/Worker 本课无新表。
- Message 从持久消息、Run 和公开展示投影读取，完整刷新不依赖短期流日志。
- **本地 Docker Redis 为必选依赖。** Run 从 Redis Streams 按游标读取短期增量；高频文本不逐包写数据库。数据库按批次保存完整消息和展示投影，完成、等待、审批等关键边界强制提交；关键变化使用少量 `agent_outbox` 记录补发。
- 执行恢复使用私有 Checkpoint、上下文和原结果；公开展示投影不含私有续接数据或凭据。
- M5 单实例执行与连接解耦；M6 的调度变更继续复用这两个接口和同一响应协议。

## 2. 持久化对象与命名

新增表采用现有 Agent 单数 `lower_snake_case` 风格。Agent 运行域使用 `agent_`，模型域沿用 `model_`；复用 `workflow_asset`、`mcp_connection`、`sandbox_allocation`，保留既有名字。本课不创建按课号命名的表。

```mermaid
erDiagram
    agent_session ||--o{ agent_run : contains
    agent_run ||--o{ agent_outbox : publishes
    agent_session ||--o{ agent_command : deduplicates
    agent_run ||--o{ agent_message : stores
    agent_run ||--o{ agent_step : executes
    agent_step ||--o{ agent_attempt : tries
    agent_step o|--o{ agent_step : nests
    agent_run ||--o{ agent_checkpoint : resumes
    agent_run ||--o{ agent_tool_binding : freezes
    agent_tool_binding o|--o{ agent_step : dispatches
    agent_attempt ||--o{ model_call : invokes
    model_call ||--o{ model_attempt : retries
    agent_attempt ||--o{ agent_artifact : produces
    agent_run ||--o{ agent_workflow_draft : offers
    agent_workflow_draft o|--o| workflow_asset : saves
    agent_run ||--o{ agent_wait : parks
    agent_wait ||--o| agent_action : approves
    agent_action ||--o| agent_demo_effect : applies
```

完整字段表与约束在 DATA_DESIGN 中唯一维护。Todo/Verifier/预算放 Checkpoint 的有类型 JSON；Workflow/Skill 源码和版本放所属 Step 定义快照，宿主调用日志复用子 Step/Attempt；不为这些对象建立无查询用途的重复表。

## 3. Message 与 Run：两个接口，同一响应协议

### 3.1 接口职责

以下为拟议接口，BFF 统一加 `/api`，沿用可信范围、委托身份和 CSRF 机制。

| 接口                                                | 输入                                                | 返回与职责                                                                     |
| --------------------------------------------------- | --------------------------------------------------- | ------------------------------------------------------------------------------ |
| `POST /v1/analysis/sessions/submit`                 | requestId、可选 sessionId、question、模型及案例参数 | 202 受理回执含 sessionId/runId/streamUrl；原子创建首问，重复请求返回原运行     |
| `GET /v1/analysis/sessions`                         | 当前身份、limit、分页游标                           | 会话列表元数据及最近 Run 状态                                                  |
| `GET /v1/analysis/sessions/{id}/messages`           | 历史分页游标，可选 runId 用于重载指定轮次           | **Message 接口：application/json，响应体为 AgentResponse，加载持久消息与过程** |
| `GET /v1/analysis/runs/{id}/events?after=0-0`       | 原 Run、最后已应用的 Redis Stream ID                | **Run 接口：text/event-stream，每个 data 为 AgentResponse，输出运行增量**      |
| `POST /v1/analysis/sessions/{id}/context-reset`     | requestId、expectedVersion                          | 持久上下文起点及元数据回执                                                     |
| `POST /v1/analysis/runs/{id}/{pause,resume,cancel}` | requestId、expectedVersion                          | 控制回执；运行变化经 Run 流推送，Message 可重新读取                            |
| `POST /v1/analysis/runs/{id}/decisions`             | HITL 决定                                           | 决定回执；卡片状态经相同业务包更新                                             |
| `GET /v1/analysis/runs/{id}/artifacts/{artifactId}` | 当前权限                                            | 原字节、类型与文件名，private/no-store                                         |

Message 与 Run 是两条内容读取路径。提交、列表、控制和下载保留各自职责。用户刷新先加载 Message；存在未结束 Run 时，再使用响应中的该 Run 游标续流。完成的历史直接呈现完整内容。

### 3.2 共享 AgentResponse

JSON 响应体和每个 SSE `data` 采用完全相同的外层类型及业务包联合；仅传输方式、包数量和 snapshot/delta 语义不同。该版本仍为待实现的 `compass.run@2`。

```typescript
type AgentResponse = {
  protocol: "compass.run";
  version: 2;
  sessionId: string;
  mode: "snapshot" | "delta";
  packets: AgentPacket[];
  cursors: { runId: string; seq: string }[];
  page: { nextCursor: string | null } | null;
};

type AgentPacket = {
  packetId: string;
  runId: string;
  seq: string | null; // delta为Redis Stream ID，如"1731400000000-0"；snapshot为null
  requestId: string;
  occurredAt: string;
  event: AgentEvent; // 唯一Pydantic判别联合，见CODE_DESIGN
};
```

- Message 使用 `mode=snapshot`，page 给出分页位置；cursors 仅包含本页完整装载的 Run 及其提交边界。
- Run 使用 `mode=delta`，page 为 null；每帧包含一个或一批有序包，cursors 只包含该 Run 的最后 Stream ID。SSE id 为 `runId:seq`；seq 始终是字符串，起点为 `0-0`。
- snapshot 通过完整 upsert 包创建或替换对象，delta 可以携带相同 upsert 或文本增量。业务渲染不判断响应来自哪个接口。
- Message 的派生包使用对象 ID/revision 生成稳定快照 packetId，seq 为 null；保留真实业务时间。流式包保留原事件 ID、时间和序号。快照包不承担原始逐字拆分的身份。
- 用户和助手正文使用 `message.upsert`；Run 使用 `run.upsert`；节点、计划、旁白、脚本、审批、产物和 Timeline 使用有类型 `view.upsert`。实时文本另用 `message.delta`。完整字段见代码设计。

### 3.3 持久加载与续流衔接

1. Message 在一次一致数据库读取中获取本页完整 Run 的公开消息、public_view 及 projected_seq=C，编码 AgentResponse。Run 的展示状态取 public_view.run，和内容属于同一投影前缀；权限覆盖全部读取对象。
2. 历史分页以完整 Run 为单位，固定上界 ordinal；前序已终态 Run 内容稳定。当前活跃 Run 只在一页中完整加载，按当前 4 MiB Run 公开内容预算限制单 Run 投影。响应按字节预算减少整 Run 数量，完整装载边界不被拆开。
3. 页面应用 snapshot 后，将对应 Run 的游标设为 C；只对非终态 Run 订阅 `after=C`。加载期间产生的 C 之后增量继续从日志读取。
4. 同一 Run 的 seq 使用 Redis 原生 `毫秒-序号`，按两个整数比较、严格递增，允许数值间隔；相同包重放幂等。服务端校验游标对应的保留记录及流完整性，禁止用整数加一判断缺包。流已到期返回 `409 history_reload_required`，客户端重新调用 Message；活跃流意外丢失进入 recovery_required，保留数据库投影，停止自动续接。
5. Run 每个连接至多 60 秒或达到传输预算后轮转。网络 EOF 不更改业务状态；终态已送达则结束该 Run 订阅，新一轮使用新的 Run 接口连接。waiting/paused 仍属于未终态。
6. 两类读取均校验当前权限；长连接最长每 5 秒重新核验。退出或切换会话只停止加载与订阅。
7. snapshot 与已经应用的实时更新相遇时按对象 revision 和 Run 游标处理，旧快照不覆盖新状态。分页完成后核对列表中的最近 Run，其他页面新建的轮次通过 Message 补载。

Message 的分页和 Run 的续流游标分别传递，具有独立用途。浏览器临时缓存只保存读取进度；问答和运行历史以数据库为准。

### 3.4 同一 reducer 与展示投影

`applyAgentResponse` 先按同一 Schema 校验，再按 mode 处理快照基线或增量顺序，最后统一交给 `reduceAgentPacket`。两类传输适配器只负责 JSON 读取与 SSE 解帧。

Message 正文由 agent_message 保存；Run 的 `public_view` 保存公开 Run 头和其他已展示对象的完整投影，包括节点树、公开旁白、计划、脚本、审批、产物引用和需要展示的 Timeline。对象均有稳定 ID/revision，正文与产物字节通过引用复用。Projector 在同一 PostgreSQL 事务更新公开消息、public_view 和 projected_seq，保证快照对应完整流前缀。运行控制使用业务 Run 行；Message 和侧栏的运行状态使用公开投影。私有模型上下文、完整工具观察及执行 Checkpoint 按执行边界直接保存。

实时最终视图与 Message 加载视图通过 `normalizeBusinessView` 比较全部业务字段。快照数量、流式拆包次数、网络标志、滚动位置和本地展开偏好不参与比较。清理终态短期日志后仍须通过同一比较。

## 4. 执行写入与恢复

### 4.1 事务与顺序

锁顺序统一为 `Session → Run → Step/Attempt → Wait/Action`。业务行锁只覆盖短事务，外部模型、工具和 Redis 调用都在事务外。每 Run 的流写入由单实例内的串行发布通道负责；并行子调用的结果按接受顺序入通道。Session 使用 version 管理元数据，无独立流游标。

```mermaid
sequenceDiagram
    participant U as 浏览器
    participant A as Agent / RunService
    participant D as PostgreSQL
    participant R as Docker Redis Streams
    participant P as Publisher / Projector
    U->>A: submit(requestId, question)
    A->>D: Session / 用户消息 / Run / 关键Outbox 原子受理
    D-->>A: commit
    A-->>U: 202 + sessionId + runId
    P->>D: 读取待发布Outbox
    P->>R: XADD 首批包
    R-->>P: AOF always 持久确认
    P->>D: 消息 / public_view / projected_seq / 投递回执
    U->>A: events(after=0-0)
    A->>D: 派发前保存 Attempt / 输入 / 占额
    A->>A: 模型或工具调用
    loop 高频文本
        A->>R: 合并后 XADD
        R-->>A: 持久确认
        A-->>U: AgentResponse / delta
        P->>D: 每500ms或64KiB合并投影
    end
    A->>D: 结果 / 产物 / Checkpoint / 关键Outbox
    D-->>A: commit
    P->>R: 发布关键边界整批包
    R-->>P: 持久确认
    P->>D: 强制提交整批投影及游标、Outbox回执
    D-->>P: commit
    A-->>U: 完成 / 审批 / 暂停等关键包
    Note over U,A: 刷新由Message读SQL投影，未完成Run接续C之后的Redis流
```

- 首问去重键按 `(tenant, workspace, actor, requestId)` 唯一；首次创建使用事务级 advisory lock 序列化同键请求，原子保存 Session/Run、用户与空助手消息、初始公开视图、命令回执和首批 Outbox。同键不同输入返回 409。初始投影游标为 `0-0`；首批 Outbox 投影完成后再派发模型。
- **高频文本路径：** 50 ms 或 8 KiB 合并为一个包 → XADD → 获得 AOF 持久确认 → 允许 SSE 读取。每 Run 的 Projector 每 500 ms 或累计 64 KiB 提交一次完整投影与 projected_seq。阈值是本课初值，实施以原有单帧/单 Run 预算验证；数据库中没有逐 token 或逐 delta 行。
- **关键业务路径：** Attempt 派发意图、预算、已接受结果、产物字节、私有上下文、Checkpoint、Wait/Action 和命令回执在各自业务事务持久化；涉及公开变化时同事务插入 `agent_outbox`。Checkpoint 以 boundary_outbox_id 关联该边界，Redis ID 在提交后生成。
- Publisher 按 Run 的业务版本发布关键包，先补齐前序流，再按 Outbox 内顺序 XADD。Projector 只提交完整关键批次；公开消息、public_view、projected_seq、Outbox 投递回执同事务更新。SSE 在该事务提交后才放行整批关键包。终态的完整回答与展示状态因此先落库；下一执行步骤和下一轮也等待所需关键投影完成。
- PostgreSQL 与 Redis 使用可重试补发，无跨存储事务。Outbox 的 operationId、摘要和包 ID 稳定；发布结果不明时先在本 Run 的有界流中查相同包 ID/内容，再补缺项。禁止写命令自动盲重试。高频包采用相同的确认规则，投影按游标和对象 revision 幂等。
- Redis 或投影失败停止新派发，已返回的模型/工具结果仍先提交数据库及 Outbox，恢复后补发。不得发送尚未取得持久确认的文本或未完成投影的成功终态。具体缓存键、重试、保留与故障处置见 Redis 方案。

### 4.2 单实例生命周期

Agent lifespan 持有专用 PostgreSQL advisory lock 连接以确保一个执行所有者；拿不到锁时持久执行入口不就绪。每次启动生成 boot ID，Run 的 execution epoch 与此关联。丢失所有者连接立即停止新派发并停止当前资源；每次提交验证当前 epoch。该设计覆盖本课单实例环境，跨实例接管由 M6 租约承接。

submit 提交成功后创建应用级任务，不依附 SSE response generator。启动先建立 Redis 连接、核对保留流并重建已确认流尾，再补发未投递 Outbox、补齐数据库投影；完成这些步骤后才允许执行恢复。Publisher、Projector 与 Run 任务统一由 lifespan 管理。启动函数按 Run ID 幂等登记，锁 Run 并以状态/version 领取 epoch；重复受理回执不重复启动执行。受理后尚未启动即崩溃，保留 Created；启动后遇到遗留 Running，保存关键 Outbox，并以 `run.upsert` 标记 Paused/recovery_required 并核对未决 Attempt；无法确认资源时先保持待核对，不直接派发。Waiting/Paused 原样保留，Cancelling 只收资源回执，终态只读。M5 提供显式恢复，进程内任务创建失败也标记可恢复并向客户端返回已受理 Run。

### 4.3 Checkpoint 的完整内容

Checkpoint DTO 有独立 schemaVersion，字段合同见 DATA_DESIGN：固定运行配置和源版本、按顺序的上下文 Message ID、模型绑定与服务端私有续接数据、Todo/Verifier、剩余预算和占额、完成结果、下一执行位置、未决调用、工具目录和产物引用。恢复校验 schema、源码摘要、绑定/目录版本、权限及产物完整性后再申请执行权。

已完成 Run 只需重建视图；未完成 Run 从有效边界继续。普通模型流的 TCP 连接和 QuickJS 内存栈不落库。模型中断时立即将 Attempt 结局持久标记为 incomplete/unknown；Redis 可读后补投影已确认片段，再发布公开恢复状态。遵守原可重试分类；内容已暴露、上游结局未知或效果未知时先进入可诊断阻塞，禁止把已有片段拼接为成功输出。显式重试产生新的 Attempt，旧记录保持可读。

LLM 私有续接状态由服务端解封后使用独立 runtime-state 用途加密保存，绑定 owner/Run/provider/binding version/schema；恢复通过内部调用路径重建，保持面向浏览器 continuation token 原有 TTL，不延长旧令牌。仅保存 SDK 继续工具对话所必需的 opaque 状态；供应商密钥按当前配置取得，不进 Checkpoint。终态可清除私有续接段，保留展示消息和运行记录。

### 4.4 LLM Runtime

现有 `model_call` 保留逻辑调用摘要和模型管理查询语义；新增 `model_attempt` 保存实际调用尝试，先登记再发送。路由模型、主模型、Fallback 和子 Agent 都关联各自 agent_attempt，Standalone 模型测试允许无 Run 关联。`model_call.execution` 继续作为向后兼容的聚合字段，由 model_attempt 在收口时生成。

派发前记录保守用量/成本占额，结果到达后写真实用量；未确认项保留未知值和占额。恢复不重置预算；等待/暂停不增加活跃耗时。每个真实 Attempt 的实际请求和必要输出写受控记录，model_call 的内容列保留逻辑请求与最终接受结果，Trace/日志继续只记录安全元数据。

### 4.5 Workflow、Skill 与工具

- 每 Run 冻结工具别名、声明、Schema 摘要、策略、执行绑定及配置版本；恢复按原版本核验并重建 MCP 会话。变化返回 `tool_catalog_changed`。内置源码继续留在仓库，数据库保存版本与运行快照。
- 每个工具/子 Agent/流程节点有稳定 Step；每次执行有独立 Attempt。完整输入输出加密，安全预览和节点快照进入公开事件。Sandbox 分配记录沿用 M4，恢复不把临时文件路径当产物内容。
- Workflow Step 冻结源码、摘要、入口版本、参数和运行环境版本。QuickJS 恢复从相同脚本入口重放纯计算，通过宿主调用日志复用完成的 Step 结果；已执行模型和工具不再调用。宿主调用身份为 `(parent_step_id, call_ordinal)`，核对名称和输入摘要。
- 为保持脚本分支一致，冻结脚本可见时间和随机种子，按已提交的 delivery_no 重放 Promise 结果；所有外部能力经过宿主桥，禁止额外时钟/IO。原 `parallel` 的各子结果独立保存，Join 后再提交父 Step。恢复中调用顺序或摘要不匹配返回 `workflow_replay_mismatch`。具体算法见 CODE_DESIGN。
- Skill 保存实际加载的正文/资源版本或内容摘要及必要内容，不仅保存易变的磁盘路径。引用的 Workflow 资产即使后续停用/修改，历史展示使用原快照；后续实际执行仍核验当前权限和配置。
- `agent_workflow_draft` 保存通过运行校验的脚本与来源，沿用 30 分钟保存邀请有效期；保存资产和 `workflow.saved` 同事务完成，重复请求返回同一 assetId。过期草稿仍可展示源码与失效状态。

## 5. 权限、容量与兼容

Session 默认按 owner/tenant/workspace 隔离；Run、消息、事件、产物通过同一归属约束查询。审批人仅获提案所需范围，独立提案查询不等于获得完整会话。Agent 使用现有可信委托，并通过拟新增 Web 内部权限核验接口查询当前身份；接口不依赖过期浏览器会话，不跨库查询。授权失败关闭读取或推进。

沿用原单帧/单 Run 预算，并为 Run 流分连接累计传输预算。artifact 大小沿用 M4；私有 JSON 按原消息、模型输入和工具输出上限校验。到达限额保存明确失败状态，禁止静默截掉历史或恢复字段。业务消息、运行记录和完整展示投影持续保留。Run 已终态、投影追到流尾、Outbox 全部投递后，才给整条 Redis Stream 设置 1 小时 TTL。活跃/等待/暂停流不设置 TTL，不使用 MAXLEN 裁剪；沿用每 Run 容量限制，达到 Redis noeviction 上限时停止派发并保留已有内容。缓存到期后 Message 仍可加载完整历史。

本地依赖采用固定版本 Redis Docker 镜像、命名卷和 AOF always；宿主绑定 `127.0.0.1:56379`，Agent 容器使用 `redis:6379`。`/healthz` 保持进程检查，持久执行的 `/readyz` 同时检查 PostgreSQL、Redis 和所有者就绪。Redis 故障期间，直接访问 Message 的数据库历史读取仍可用；前端不因流依赖故障屏蔽历史页。配置、拟议 Compose 片段及启动方式见 REDIS_DESIGN.md。

现有 v1 协议的 `POST /v1/analysis/runs` 保留为过渡适配器：内部同样调用持久 submit，以独立 Session 保存调用，不再走内存执行分支；外部仍编码 v1 事件，不提供历史读取。v1 的旧 history 仅在该适配器校验导入，记录为导入上下文，不能冒充旧 Session。新 Web 全部切换 v2；老客户端遇到 HITL 所需的新能力返回明确不支持。原 v1 断线取消仅保留在适配器，v2 不继承。客户端升级后移除适配器需另行确认实际消费者。

## 6. 数据库发布与恢复

遵循数据库规范。owner **agent/main**，规划 **0008 → 0009**，拟新增 `apps/agent/migrations/versions/0009_durable_runs.py`，一次包含持久化与 HITL 表；代码可分切片，迁移区间保持不变。0008 源文件已在当前工作区，实施先核对实际单一 head 与应用版本；出现冲突调整未发布 revision 及下游规划，保留已共享历史。

- 同步 ORM、Alembic env、受管版本映射、结构核验、运行角色授权及 readyz。真源在 app，Feature 不放可编辑 SQL 副本。
- 生成 `apps/agent/db/main/sql/bootstrap.sql`、`upgrades/0008__0009.sql` 及受支持起点到 0009 的增量，更新 manifest 和 README；保留原 migration、历史 SQL。
- 旧 model_call 新关联列 nullable；已有 execution 尝试摘要可确定性回填 model_attempt 并标记 legacy_summary。没有保存过的正文/Session 不回填，内容状态标记 not_captured。M4 历史 Sandbox 行无对应 Run 时继续作为遗留清理记录保留，不强加破坏性外键。
- 发布顺序：停接并排空前版执行 → 备份 agent/main 和既有/新增加密材料 → 部署本地 Redis 并检查卷、AOF、口令和健康状态 → 迁移和权限核验 → 发布 Agent 与生成契约/BFF → 切换 Web 会话页 → 冒烟和刷新验证。
- 恢复优先使用兼容 0009 的构建保留全部运行数据；回旧 schema 时把升级前备份恢复至独立库后切换，保留 0009 库。动作效果和 Action ID 一并核对，避免恢复后重复施效。无删除新表的常规回退步骤。
- 后续备份先停止新派发，等待关键 Outbox 和投影提交，再协调保存 PostgreSQL 与 Redis 卷。恢复时核对原 Run 流及 projected_seq；缺失或落后的活跃流保持 recovery_required，不重建同名空流后自动接续。命名卷保留、容器重启验收与主动损坏后的处置见 Redis 方案。
- Web/Memory/Worker/Retail 无新业务迁移。恢复密钥配置拟为 `COMPASS_RUNTIME_STATE_KEY`，缺失拒绝开启持久运行；密钥丢失时历史公开视图可读，私有执行恢复返回明确错误。

## 7. 实施任务与评审重点

以下均为拟实施路径，`!` 表示修改现有或 M4 前置目标，`+` 表示本课新增。

```diff
+ apps/agent/src/compass_agent/runtime/entities.py
+ apps/agent/src/compass_agent/runtime/store.py
+ apps/agent/src/compass_agent/runtime/checkpoints.py
+ apps/agent/src/compass_agent/runtime/{message_reader,run_events,public_projection}.py
+ apps/agent/src/compass_agent/runtime/{redis_stream,outbox_publisher}.py
+ apps/agent/src/compass_agent/runtime/hitl.py
! apps/agent/src/compass_agent/runtime/{service,control,stream,execution_trace}.py
! apps/agent/src/compass_agent/harness/{executor,context,controlled_run,autonomy}.py
! apps/agent/src/compass_agent/workflows/{script,assets,drafts}.py
! apps/agent/workflow-runner/run.mjs
! apps/agent/src/compass_agent/tools/{loader,dispatcher,artifacts}.py
! apps/agent/src/compass_agent/models/{entities,repository,service}.py
! apps/agent/src/compass_agent/llm/{contracts,executor,continuation}.py
+ apps/agent/src/compass_agent/api/sessions.py
! apps/agent/src/compass_agent/api/runs.py
! apps/agent/src/compass_agent/{schemas,main,settings}.py
+ apps/agent/migrations/versions/0009_durable_runs.py
! apps/agent/migrations/env.py
! apps/agent/scripts/database.py
! apps/agent/db/main/{README.md,sql/}
! apps/web/src/{client,contracts}/analysis-run.ts
+ apps/web/src/server/http/analysis-session-handler.ts
+ apps/web/src/server/http/analysis-run-authz-handler.ts
! apps/web/src/server/{analysis-agent-client.ts,http/analysis-run-handler.ts}
! apps/web/src/server/http/handler.ts
! apps/web/src/components/{analysis-composer,analysis-run-turn}.tsx
! apps/web/src/components/shell/app-shell.tsx
! scripts/export-contracts.py
! contracts/ 与 apps/web/src/generated/  只由契约生成器更新
+ apps/agent/tests/test_durable_runtime_integration.py
+ apps/web/tests/e2e/durable-sessions.spec.ts
! apps/agent/tests/test_database_tools_integration.py
! apps/web/tests/analysis-run-stream.test.ts
! apps/agent/package.json  将新增真库测试纳入 test:integration
! apps/agent/pyproject.toml 与 uv.lock  Redis asyncio 客户端
! deploy/compose/compose.yaml
+ deploy/redis/redis.conf
! .env.example
! deploy/README.md、apps/agent/README.md 与受影响 manifest.yml
```

| 任务               | 依赖与交付                                                                 | 验收                       |
| ------------------ | -------------------------------------------------------------------------- | -------------------------- |
| T0 本地 Redis      | T2 前交付 Compose、AOF/卷、口令、客户端、健康检查与启动说明                | AC-19                      |
| T1 对象清单和迁移  | 核对 M4 基线；落完整实体、约束、密钥用途、SQL、旧数据兼容                  | AC-01、AC-07、AC-08        |
| T2 Session/消息/流 | 原子 submit、幂等、Redis Streams、关键 Outbox、批量/强制投影、双接口与列表 | AC-09、AC-10、AC-17～AC-19 |
| T3 逐层运行持久化  | LLM Attempt、工具目录/结果、计划、Verifier、预算、Workflow/Skill/草稿      | AC-13～AC-16               |
| T4 执行恢复        | 独立任务、Checkpoint、QuickJS 日志重放、未知结局和原产物读取               | AC-01、AC-03、AC-05、AC-11 |
| T5 Web 统一渲染    | AgentResponse schema、JSON/SSE BFF、同一 reducer、真实侧栏、刷新/切换/追问 | AC-09～AC-12、AC-18        |
| T6 HITL 增量       | 按独立方案实现审批/控制/动作核对，复用 T1～T5                              | AC-02～AC-06               |
| T7 全案例验收      | 固定前序案例矩阵，浏览器刷新比对、实际重启和迁移恢复                       | 全部 AC                    |

本次必须评审：Redis 持久确认、关键 Outbox 补发、消息/展示投影与游标原子性、终态展示门禁、LLM 派发记录、QuickJS 重放确定性、旧模型记录兼容、v1 过渡、HITL 取消竞态。代码骨架见 CODE_DESIGN；详细字段见 DATA_DESIGN。最高优先验证为“提交后发送前退出仍可经 Message 加载，接续 Run 无重复”和“并行 Workflow 完成一个子调用后重启，完成项不再调用”。

实施时执行 Agent/Web lint、typecheck、test，`pnpm contracts` 与 `pnpm contracts:check`；真实 PostgreSQL 和本地 Docker Redis 下执行 `pnpm test:integration -F agent`、`pnpm db:sql:check -F agent`、migrate、重复 seed 和 smoke；按跨应用变更执行 `pnpm check`、`pnpm build`，浏览器用实际登记入口验收。新增集成测试入口须先接入 package.json，不能以未登记命令报告通过。

本次仅更新设计。数据库迁移、模型调用、浏览器业务回归和重启验收均待实施；文档与 HTML 检查单独记录，不代替这些业务结果。


## 第 19 课 · 持久化与双接口同协议代码设计

[返回主方案](TECH_DESIGN.md) · Redis 方案 · 数据合同 · HITL 方案

以下是拟议 Python/TypeScript 评审伪代码，尚未实现或运行。省略 ORM 映射、依赖注入和错误响应样板；关键事务、身份、幂等、派发、回放和失败分支展开。事务工厂退出成功后才可发送回执。任何外部模型、工具或 Web 权限请求都在数据库事务之外。

## 1. 原子受理与提交后发布

拟新增 `runtime/store.py`，修改 M4 目标 `runtime/service.py`。

```python
def submit(command, actor):
    require_current_scope(actor)
    digest = canonical_digest(command)
    with database.transaction() as tx:
        tx.lock_submission_key(actor.scope, actor.id, command.request_id)
        previous = tx.command(actor.scope, actor.id, command.request_id)
        if previous:
            require_equal(previous.request_sha256, digest, "request_conflict")
            return previous.response
        require_cached_runtime_readiness()  # 仅读取本进程就绪标记；原回执不依赖Redis。
        session = tx.lock_owned_session(command.session_id, actor) if command.session_id else tx.create_session(actor, command.question)
        require_no_active_run_and_previous_projection_complete(tx, session.id)
        run = tx.create_run(session, command, projected_seq="0-0")
        message = tx.create_user_message(run, command.question)
        assistant = tx.create_empty_assistant_message(run)
        tx.bootstrap_public_view(run)  # 初始created状态，与原问题一起持久保存。
        packets = [run_upsert(run), message_upsert(message), message_upsert(assistant)]
        tx.insert_outbox(run, command.request_id, digest, packets)
        ack = accepted(session.id, run.id)
        tx.record_command(actor, command, digest, ack, session.id, run.id)
    return ack  # 首批Outbox投影后，应用级任务才允许派发模型。


def commit_boundary(run_id, epoch, previous_checkpoint, operation_id, outcome):
    session_id = database.session_of_run(run_id)
    with database.transaction() as tx:
        session = tx.lock_session(session_id)
        run = tx.lock_run(run_id)
        old = tx.operation_outbox(run.id, operation_id)
        if old:
            require_equal(old.operation_sha256, outcome.digest, "operation_conflict")
            return old.boundary_receipt
        if run.is_terminal:
            return tx.require_same_terminal_outcome_and_receipt(run, outcome)
        require_epoch(run, epoch)
        require_checkpoint(run, previous_checkpoint)
        if run.status == "cancelling":
            return tx.commit_cancelling_result_and_outbox(session, run, outcome)
        require_status(run, "running")
        tx.require_open_attempt(run.id, outcome.attempt_id)
        for artifact in outcome.artifacts:
            require_size_digest_and_scope(artifact, run)
            tx.insert_artifact_or_verify_identical(artifact)
        tx.require_checkpoint_references(outcome.checkpoint, run)
        tx.accept_attempt_and_step(outcome)
        tx.insert_private_context_messages(outcome.context_messages)
        if outcome.wait:
            tx.insert_wait_and_release_epoch(run, outcome.wait)
        elif run.control_intent == "pause":
            tx.pause_and_release_epoch(run)
        elif outcome.terminal:
            tx.finish_run(run, outcome.terminal)
        tx.bump_versions(session, run)
        checkpoint = tx.prepare_checkpoint(run, outcome.checkpoint)
        packets = tx.encode_boundary_packets(run, outcome, checkpoint)
        outbox = tx.insert_outbox(run, operation_id, outcome.digest, packets)
        tx.insert_checkpoint(checkpoint, boundary_outbox_id=outbox.id)
    publisher.wake(run_id)
    return boundary_receipt(checkpoint.number, outbox.id)


async def publish_delta(run_id, packet):
    # 所有发布走同一Run通道；边界前先排完已有delta，边界后等待投影。
    async with channels.for_run(run_id):
        await publisher.require_no_pending_boundary(run_id)
        require_current_owner()
        seq = await redis_stream.append_confirmed_once(run_id, packet)
        confirmed_tail.advance(run_id, seq)
        projector.wake(run_id)  # 500ms或64KiB合并，终止时强制刷新。
        readers.notify(run_id)


async def flush_boundary(run_id, outbox_id):
    async with channels.for_run(run_id):
        # 按run_version补齐此前未投递批次，不能越过早先的关键变化。
        for batch in await store.pending_outboxes_through(run_id, outbox_id):
            ids = []
            for index, packet in enumerate(batch.packets):
                seq = await redis_stream.append_confirmed_once(
                    run_id, packet, outbox_id=batch.id,
                    batch_index=index, batch_size=len(batch.packets),
                )
                ids.append(seq)
            confirmed_tail.advance(run_id, ids[-1])
            # 这里将整批内容、projected_seq、Outbox回执同事务提交。
            await projector.flush_through(run_id, ids[-1])
            await store.require_outbox_delivered(batch.id)
            readers.notify(run_id)
    # 调用者等待本函数完成后才允许依赖本边界的外部派发。
```

append_confirmed_once 生成包 ID 一次并复用，写命令关闭盲重试。写入结果不明时先 XRANGE 查询有界 Run 流的相同 packetId，核对内容后确认或补写。Redis AOF always 成功确认后才推进进程内 confirmed_tail；启动核对持久流后先重建该位置，再补发和补投影。存储不可用时不回退为纯内存输出。

普通 delta 仅写 Redis。公开消息/public_view 由 Projector 统一更新，私有上下文和原执行结果由 Runtime Store 写业务记录。Projector 按游标从 Redis 读取并合并，事务锁定 Run 后再次检查原游标，以免重复应用；关键批次不拆开提交。Cancelling 分支继续保存已到达输出、效果和清理回执，禁止后继派发。

## 2. 两个接口与同一响应处理器

拟新增 `runtime/message_reader.py`、`runtime/run_events.py`、`runtime/public_projection.py`、`runtime/redis_stream.py` 和 `runtime/outbox_publisher.py`。响应外层 AgentResponse 与 AgentPacket 唯一维护于主方案第 3.2 节，实际实现由 schemas.py 生成；此处展开共享业务联合和读取逻辑。

```python
def messages(session_id, page_cursor, run_id, actor):
    authz.require_session_read(actor, session_id)
    with database.read_snapshot() as tx:
        runs, next_page = tx.page_owned_runs(session_id, actor, page_cursor, run_id)
        packets, cursors = [], []
        for run in runs:
            saved_messages = tx.public_messages(run.id)
            view = tx.public_view(run.id)
            # 使用已投影Run头，不能混入较新的业务Run.status。
            packets.extend(encode_complete_upserts(view.run, saved_messages, view.objects))
            cursors.append({"runId": run.id, "seq": run.projected_seq})
        body = AgentResponse(
            sessionId=session_id, mode="snapshot", packets=packets,
            cursors=cursors, page={"nextCursor": next_page},
        )
        validate_response(body)
    return json_response(body, cache_control="no-store")


async def project_prefix(run_id, target=None):
    # 独立有界任务；正常每500ms或64KiB，关键边界指定target强制提交。
    base = await store.read_projection(run_id)
    rows = await redis_stream.read_confirmed_after(run_id, base.seq, through=target)
    rows = complete_boundary_prefix(rows)  # 不保留半个Outbox批次到SQL。
    if not rows:
        return
    next_view = reduce_public_rows(base, rows)
    with database.transaction() as tx:
        run = tx.lock_run(run_id)
        require(run.projected_seq == base.seq, "projection_retry")
        tx.save_public_messages_and_view(run, next_view)
        tx.set_projected_seq(run, rows[-1].id)
        tx.mark_complete_outboxes_delivered(rows)
    # 仅终态、无待投递Outbox且投影到流尾时可以设置整键TTL。
    await redis_stream.expire_if_fully_projected_terminal(run_id, seconds=3600)


async def run_events(run_id, after, actor):
    await authz.require_run_read(actor, run_id)
    require_stream_id(after)
    # 头部发出前验证归属、游标、流存在性；失效409、丢失410、依赖故障503。
    await redis_stream.validate_resume(run_id, after)
    cursor = after
    while transport_budget.remaining:
        await authz.require_run_read(actor, run_id, max_age_s=5)
        run = await store.read_run_and_projection(run_id)
        rows = await redis_stream.read_confirmed_after(run_id, cursor, limit=16)
        # 普通包已获AOF确认；关键包仅在整批已投影后可见，不能越过该批。
        rows = visible_prefix(rows, projected_seq=run.projected_seq)
        rows = take_encodable_prefix(rows, frame_bytes=256 * 1024, max_items=16)
        if rows:
            require_strictly_increasing_ids(rows, cursor)  # Redis ID允许间隔。
            body = AgentResponse(
                sessionId=run.session_id, mode="delta",
                packets=[packet_from_stream_entry(row) for row in rows],
                cursors=[{"runId": run_id, "seq": rows[-1].id}], page=None,
            )
            validate_response(body)
            yield encode_sse(id=f"{run_id}:{rows[-1].id}", data=body)
            cursor = rows[-1].id
        if run.public_terminal and run.all_outboxes_delivered and cursor == run.projected_seq:
            return
        yield sse_comment("keepalive")
        await readers.wait_or_poll(run_id, timeout_s=1)
        await redis_stream.require_retained_stream(run_id, cursor)
    # 传输结束不改变业务状态；连接中途错误断流，下次握手返回明确错误码。
```

下面的 value 类型复用对应的公开 DTO；审批、草稿和产物字段沿 DATA_DESIGN/HITL_DESIGN 展开。每个对象的稳定 ID 必须与 DTO 内部身份匹配，私有字段禁止进入该联合。

```typescript
type MessageSnapshot = {
  messageId: string;
  ordinal: number;
  role: "user" | "assistant";
  revision: number;
  status: "streaming" | "completed" | "incomplete";
  content: { text: string; artifactIds: string[] };
};

type PublicViewObject = {
  objectId: string;
  revision: number;
} & (
  | { kind: "execution.node"; value: ExecutionNodeSnapshot }
  | { kind: "plan"; value: PublicPlanSnapshot }
  | { kind: "narration"; value: PublicNarration }
  | { kind: "workflow"; value: PublicWorkflowSnapshot }
  | { kind: "approval"; value: PublicApprovalSnapshot }
  | { kind: "artifact"; value: PublicArtifactMetadata }
  | { kind: "timeline"; value: PublicTimelineEntry }
);

type AgentEvent =
  | { type: "message.upsert"; payload: MessageSnapshot }
  | {
      type: "message.delta";
      payload: { messageId: string; revision: number; text: string };
    }
  | {
      type: "run.upsert";
      payload: {
        ordinal: number;
        version: number;
        status: RunStatus;
        reasonCode: SafeReason | null;
        recoveryStatus: RecoveryStatus;
        cleanupStatus: CleanupStatus;
      };
    }
  | { type: "view.upsert"; payload: PublicViewObject };
```

upsert 首次出现时创建对象，已有对象按 revision/version 替换；相同版本同内容为幂等，版本冲突且内容不同报协议错误，旧版本忽略。message.delta 只追加到已存在消息的下一个 revision。正文完成后用完整 message.upsert 收口为 completed/incomplete；终态 run.upsert 与完整结果形成关键 Outbox；投影提交完成后再从流输出。历史通过相同 upsert 直接恢复完整内容，保留节点父子关系、公开旁白顺序和实际展示的 Timeline。

Agent 将既有 routing/step/tool/extension 过程转换为上述公开对象更新，通过统一 Projector 维护 public_view；v1 适配器继续编码原合同。转换规则只有一份业务对象定义；两个 v2 接口都使用它，新增或修改展示字段时共同升级 Schema。

```typescript
function compareStreamId(a: string, b: string): number {
  const [am, as] = parseStreamId(a); // 校验格式后转为两个bigint。
  const [bm, bs] = parseStreamId(b);
  return am === bm ? (as === bs ? 0 : as < bs ? -1 : 1) : am < bm ? -1 : 1;
}

function applyAgentResponse(state: SessionView, input: unknown): SessionView {
  const body = validateAgentResponse(input);
  require(body.sessionId === state.sessionId, "session_mismatch");
  let next = cloneViewForAtomicApply(state);
  if (body.mode === "snapshot") {
    for (const cursor of body.cursors) {
      const last = next.runSeq[cursor.runId] ?? "0-0";
      if (compareStreamId(cursor.seq, last) < 0) continue;
      next = clearRunProjection(next, cursor.runId);
      for (const packet of body.packets.filter((p) => p.runId === cursor.runId)) {
        require(packet.seq === null, "snapshot_cursor_invalid");
        next = reduceAgentPacket(next, packet);
      }
      next.runSeq[cursor.runId] = cursor.seq;
    }
  } else {
    require(body.cursors.length === 1 && body.page === null, "stream_envelope_invalid");
    requireStrictPacketOrder(body.packets); // 帧内严格递增，序号无需相邻。
    for (const packet of body.packets) {
      require(packet.runId === body.cursors[0].runId, "run_mismatch");
      require(packet.seq !== null, "delta_cursor_missing");
      const last = next.runSeq[packet.runId] ?? "0-0";
      if (compareStreamId(packet.seq, last) <= 0) continue;
      next = reduceAgentPacket(next, packet); // delta按messageId/revision防止重复追加。
      next.runSeq[packet.runId] = packet.seq;
    }
    requireEnvelopeCursorMatchesPackets(body);
  }
  return next; // 整帧成功后才发布状态和游标。
}

async function loadMessages(sessionId: string, options: MessageReadOptions) {
  const response = await getMessages(sessionId, options);
  updateView((state) => applyAgentResponse(state, response));
  return response;
}

async function followRun(runId: string, signal: AbortSignal) {
  while (!signal.aborted && !isTerminal(currentView(), runId)) {
    const response = await getRunEvents(runId, lastAppliedSeq(runId), signal);
    if (response.status === 409 && (await isHistoryReloadRequired(response))) {
      await loadMessages(currentSessionId(), { runId, signal });
      continue;
    }
    if (response.status === 410 && (await isStreamDataLost(response))) {
      await loadMessages(currentSessionId(), { runId, signal });
      showRecoveryBlocked(runId); // 保留更近的本地内容，停止自动重连。
      return;
    }
    if (response.status === 503) {
      showSyncUnavailable(runId);
      await reconnectBackoff(signal);
      continue;
    }
    requireSuccessfulResponse(response);
    for await (const body of parseSseData(response, signal)) {
      updateView((state) => applyAgentResponse(state, body));
    }
    if (!isTerminal(currentView(), runId)) await reconnectBackoff(signal);
  }
}
```

首次打开先调用 loadMessages；历史分页继续使用此函数；已装载的非终态 Run 再调用 followRun。首次 submit 得到新 Run 后可从 `0-0` 接收其创建与后续增量。业务状态只经 applyAgentResponse 更新，JSON/SSE 读取代码独立处理传输。结构错误停止并提示重载；权限错误退出相应会话视图；两类错误不进入无限重试。

## 3. 真实模型 Attempt 的写入接缝

修改 `llm/executor.py`，通过窄 `AttemptRecorder` 端口连接 `models/repository.py`，LLM 适配器不导入 Runtime Store。无持久 Run 的模型测试同样记录 model_attempt，内容采集沿原测试政策。

```python
async def invoke_attempt(call, attempt_no, request, recorder, provider):
    saved = await recorder.prepare(
        call_id=call.id, number=attempt_no,
        provider=request.spec, reservation=request.budget_reservation,
    )
    if saved.terminal:
        return await recorder.read_result(saved.id)
    if saved.dispatched_at is not None:
        raise RecoveryRequired("upstream_outcome_unknown")
    # 先持久派发意图，派发窗口崩溃也保守占额。
    await recorder.mark_dispatched(saved.id)
    try:
        result = await provider.invoke(request)
    except BaseException:
        await recorder.mark_unknown_or_leave_dispatched(saved.id)
        raise
    await recorder.finish_attempt(saved.id, result)
    # result未持久成功时调用方不可提交成功终态。
    return result
```

运行中的 retry/fallback 先执行原 policy 判定，再产生新 model_attempt；上游结果未知、已暴露内容或清理未确认均沿用原拒绝重试语义。模型 token 回调经 Runtime 持久 delta sink 写公开事件；私有协议 continuation 通过单独加密端口保存，不进入 sink。

## 4. Workflow 日志恢复

修改 M4 目标 `workflows/script.py` 与真实 `workflow-runner/run.mjs`。纯 JS 从原入口重新计算；宿主边界稳定记录，执行过的外部能力取原结果。

```python
async def handle_host_call(workflow, frame, journal, dispatcher):
    key = (workflow.step_id, frame.call_ordinal)
    digest = canonical_digest((frame.kind, frame.name, frame.input))
    saved = await journal.lookup(key)
    if saved:
        require(saved.input_sha256 == digest, "workflow_replay_mismatch")
        if saved.accepted_attempt_id:
            # 按原delivery_no排队交回QuickJS，不重复发布旧过程节点。
            return await journal.replay_delivery(saved)
        if saved.outcome_unknown:
            raise RecoveryRequired("execution_unknown")
        require(saved.safe_to_resume, "resume_blocked")
    else:
        saved = await journal.prepare_host_step(key, digest, frame)
    result = await dispatcher.execute_or_resume(saved)
    # 完整结果、接受的Attempt、delivery_no与事件先提交。
    delivered = await journal.commit_result(saved, result)
    return await journal.deliver_in_recorded_order(delivered)
```

父流程冻结 logicalTime/randomSeed，QuickJS 的 Date/随机入口使用确定性实现，其他外部 IO 全走桥。所有宿主返回顺序，包括并行结果，分配 delivery_no 后再交付；恢复加载原 journal，依次释放对应 Promise，并泵送相同 microtask 顺序。重放已接受结果时不再增加模型/工具预算，不重复节点事件。每个完成子 Step 可独立恢复，父 Join 的完成结果另做 Checkpoint。

实施先验证原 parallel 案例、条件分支、随机/时间与 Promise 竞争：脚本相同却产生不同宿主调用序列时必须报 mismatch。资源耗尽、脚本版本变化或日志缺失同样阻止接续。保持完整历史可读，不回退到无记录地重新调用全部子 Agent。

## 5. HITL 事务与效果核对

拟新增 `runtime/hitl.py`。外部权限请求在事务前完成，资源状态在事务内再次核验。

```python
def record_decision(command, actor, current_access):
    require_current_approval_access(actor, current_access, command.decision)
    with database.transaction() as tx:
        session, run = tx.lock_session_then_run(command.run_id)
        previous = tx.command_for(actor, command.request_id)
        if previous:
            return same_input_or_conflict(previous, command)
        wait = tx.lock_wait(command.wait_id)
        require_same_run_proposal_and_digest(run, wait, command)
        if wait.decision_id == command.decision_id:
            return same_decision_or_conflict(wait, command)
        require_version(run, command.expected_version)
        require_status(run, "waiting")
        require_status(wait, "pending")
        if tx.now() >= wait.expires_at:
            # 提交过期状态，再由API返回409；不能抛异常回滚到pending。
            ack = tx.expire_wait_and_record_result(session, run, wait)
            tx.record_command_receipt(actor, command, ack)
            return ack
        if command.decision == "reject":
            ack = tx.close_action_branch_with_saved_analysis(session, run, wait, command)
            tx.record_command_receipt(actor, command, ack)
            return ack
        tx.approve_wait(wait, command, actor)
        tx.create_action_once(wait, stable_action_id(wait))
        epoch = tx.set_running_with_new_epoch(run)
        ack = tx.record_decision_state_and_outbox(session, run, wait, epoch)
        tx.record_command_receipt(actor, command, ack)
    return ack


async def continue_approved_action(run_id, approval, epoch):
    previous = await adapter.lookup(approval.action_id)
    if previous.is_applied:
        return await store.record_receipt_without_new_effect(run_id, previous)
    if previous.is_unknown:
        return await store.wait_for_reconciliation(run_id, approval.action_id)
    await publisher.require_decision_projected(run_id, approval.decision_id)
    require_runtime_dependencies_ready()
    access = await web_authz.recheck_approval_and_execution(approval)
    if not access.allowed:
        return await store.record_authorization_denied(run_id)
    # 适配器独立短事务按Session→Run→Wait→Action锁序，检查epoch/取消/摘要。
    applied = await adapter.apply_if_current(run_id, epoch, access, approval)
    if applied.is_unknown:
        return await store.wait_for_reconciliation(run_id, approval.action_id)
    if not applied.is_applied:
        return await store.record_action_denied(run_id, applied.code)
    return await store.record_receipt_without_new_effect(run_id, applied)
```

批准、拒绝、到期和取消的事务辅助函数均同事务登记对应 Outbox；受理回执不直接覆盖前端展示状态，原 Run 任务等待决定的关键投影完成再派发。

同 actionId 的效果写入有唯一约束，冲突读取原效果并验证摘要；取消先提交时禁止新增效果。核对已有回执允许在撤权或 Cancelling 后内部完成，但不得再派发后续动作。故障测试应在效果 commit 后、Run 回执前真实终止进程。

## 6. 评审与实施验证

重点核对：受理幂等键在无 Session 时的并发；Session/Run 锁序；终态与最后回答的投影提交门禁；delta 的 Redis 持久确认；Outbox 部分发布恢复；Message投影游标与Run续流无遗漏；LLM 派发窗口；QuickJS 结果交付顺序；审批过期提交后返回错误；取消和效果写入的同锁裁决。这里只交付设计伪代码，语法/运行与数据库行为验证在实施阶段执行。


## 第 19 课 · 持久化数据结构

[返回技术方案](TECH_DESIGN.md) · Redis 数据与部署 · HITL 增量 · [PRD](PRD.md)

> 拟议结构，owner `agent/main`，PostgreSQL 17，规划迁移 0008 → 0009；2026-11-12。以下定义为本课字段与约束的维护源，尚未生成生产迁移。

## 1. 命名与公共约定

- 表名用单数、小写下划线：Agent 运行 `agent_<entity>`，模型执行 `model_<entity>`。保留原 `workflow_asset`、`mcp_connection`、`sandbox_allocation`，不统一重命名已有表。
- 主键 UUID 由服务端生成，外键 `<entity>_id`。模型原主键 `model_call.call_id` 保留。外部 tenant/workspace/user ID 是逻辑关联，禁止跨库 FK。
- 时间使用 `timestamptz`，`created_at` 默认数据库当前时间；`updated_at` 由业务事务更新。持续时间 `_ms`，大小 `_bytes`，成本 `_microusd`，预算变更 `_cent`，摘要为小写 hex SHA-256。
- `pk_ / fk_ / uq_ / ix_ / ck_` + 表名 + 字段/语义；名称超 PostgreSQL 63 字节时使用确定性短后缀，生成器与迁移一致。
- 图中“可空”字段可 NULL，其余 NOT NULL。JSON 均有明确 DTO/schemaVersion 和大小限制；不保存 Python 对象序列化。计数默认 0，version/revision 默认 1，ordinal/attempt number 从 1 开始；流游标为 Redis 原生 ID 字符串，初值 `0-0`。
- 所有同 Run/Session 的引用均验证归属。跨多级关系增加 `(run_id,id)`、`(session_id,id)` 等唯一键并使用复合 FK；仅图中的单列 FK 标记不替代此约束。删除默认 RESTRICT，业务记录本课不做清理或级联删除；Redis 短期流按单独保留规则过期。
- 私有密文为应用加密 envelope：用途、key ID、schemaVersion、owner/Run 绑定和密文，存 bytea；不存模型密钥、连接口令、进程句柄。公开日志和展示投影包含获准展示内容，依靠应用访问控制和数据库角色保护，不进入通用日志。

## 2. 会话、消息与运行

```mermaid
erDiagram
    agent_session ||--o{ agent_run : contains
    agent_run ||--o{ agent_message : contains
    agent_session {
        uuid id PK "分析会话"
        uuid tenant_id "租户逻辑标识"
        uuid workspace_id "工作区逻辑标识"
        uuid owner_user_id "会话所有者"
        text title "首问标题"
        bigint version "元数据与上下文控制版本"
        int next_run_ordinal "下轮序号 默认1"
        int context_start_ordinal "模型历史起点 默认1"
        timestamptz created_at "创建时间"
        timestamptz updated_at "最后业务活动时间"
    }
    agent_run {
        uuid id PK "运行标识"
        uuid session_id FK "所属会话"
        uuid request_id "原提交请求"
        int ordinal "会话内轮次"
        text status "运行生命周期"
        bigint version "控制版本"
        text projected_seq "SQL展示投影对应的Stream ID 默认0-0"
        bigint checkpoint_no "最新检查点 可空"
        uuid execution_epoch "当前执行权 可空"
        uuid owner_boot_id "单实例启动标识 可空"
        text control_intent "pause或cancel 可空"
        text recovery_status "ready required blocked 默认ready"
        text cleanup_status "none pending confirmed unconfirmed"
        text reason_code "安全原因 可空"
        jsonb config_snapshot "模型 路由 案例 源版本及限额"
        jsonb public_view "公开Run头与过程投影 初始created"
        timestamptz created_at "受理时间"
        timestamptz started_at "首次执行时间 可空"
        timestamptz finished_at "终态时间 可空"
        bigint active_ms "累计活跃时间 默认0"
    }
    agent_message {
        uuid id PK "稳定消息标识"
        uuid run_id FK "所属运行"
        uuid step_id FK "来源步骤 可空"
        uuid attempt_id FK "来源尝试 可空"
        int ordinal "Run内消息顺序"
        text channel "conversation或context"
        text role "system user assistant tool"
        text status "streaming completed incomplete"
        int revision "消息修订"
        jsonb public_content "公开规范内容 可空"
        bytea private_content "内部规范消息密文 可空"
        text content_sha256 "规范内容摘要"
        text tool_call_id "模型侧工具标识 可空"
        timestamptz created_at "创建时间"
        timestamptz updated_at "内容提交时间"
    }
```

约束及访问路径：

- Session 列表索引 `(tenant_id,workspace_id,owner_user_id,updated_at DESC,id DESC)`。`context_start_ordinal > 0 AND <= next_run_ordinal`。活动时间只在业务提交更新，读取不改变排序。
- Run 唯一 `(session_id,ordinal)` 与 `(session_id,request_id)`。部分唯一索引限制每 Session 一条非终态 Run，覆盖 created/running/waiting/paused/cancelling。状态用小写 `created/running/waiting/paused/cancelling/completed/failed/canceled`，保留原接口 canceled 拼法；课堂文案 Cancelled 表达同一状态。
- 终态要求 finished_at；非终态 finished_at 为空。Run 不存第二份最终回答正文，最终助手 Message 与公开过程投影同事务更新。public_view 为有类型结构 `{schemaVersion, run, objects}`，run 保存与投影前缀一致的 RunPublicSnapshot（ordinal、version、status、reasonCode、recoveryStatus、cleanupStatus），objects 按稳定对象 ID 保存节点、计划、旁白、Workflow、审批、产物元数据和可见 Timeline 的最新完整对象及 revision；正文和文件字节继续引用 Message/Artifact。Message API 一致读取它们及 Run.projected_seq，侧栏状态同样使用 public_view.run。业务 Run.status/version 可先于投影变化，用于执行控制；Projector 不反写业务状态。Redis 依赖故障可能造成投影暂时落后，响应明确保留最后已提交展示状态。
- Message 唯一 `(run_id,ordinal)`。conversation 消息只允许 user/assistant，使用 public_content；context 使用 private_content，两者恰有一个非空。内容为版本化的 text/toolCalls/artifactRefs，完整保留允许展示的内容。
- 每 Run 一个 conversation user 消息、一个 conversation assistant 回答，以部分唯一键保护。实时 message.delta 带 messageId/revision，持久加载和完成收口使用完整 message.upsert；失败时标 incomplete。context 可有多个模型/工具消息，并保留原顺序。

## 3. 步骤、尝试与工具目录

```mermaid
erDiagram
    agent_run ||--o{ agent_tool_binding : freezes
    agent_run ||--o{ agent_step : executes
    agent_tool_binding o|--o{ agent_step : selects
    agent_step o|--o{ agent_step : parents
    agent_step ||--o{ agent_attempt : tries
    agent_tool_binding {
        uuid id PK "本Run目录项"
        uuid run_id FK "所属运行"
        text catalog_id "冻结目录标识"
        text alias "模型侧工具名"
        text original_name "源工具名"
        text source "builtin mcp workflow skill"
        text config_ref "配置或资产逻辑引用 可空"
        int config_revision "配置版本 可空"
        jsonb declaration "名称 描述 参数Schema"
        text schema_sha256 "参数Schema摘要"
        jsonb binding "执行类型及非敏感绑定"
        jsonb policy "effect approval 批次限制"
        timestamptz created_at "冻结时间"
    }
    agent_step {
        uuid id PK "稳定逻辑步骤"
        uuid run_id FK "所属运行"
        uuid parent_step_id FK "父步骤 可空"
        text node_key "稳定节点或宿主调用路径"
        text kind "routing model tool workflow skill subagent control"
        int ordinal "Run内创建顺序"
        int call_ordinal "父流程宿主调用序号 可空"
        uuid tool_binding_id FK "工具目录项 可空"
        text group_id "并行组 可空"
        text status "pending running waiting completed failed canceled"
        int revision "公开节点版本"
        jsonb definition_snapshot "固定源码 版本 入口 逻辑时间及随机种子"
        text input_sha256 "接受输入摘要"
        uuid accepted_attempt_id FK "已接受尝试 可空"
        timestamptz created_at "创建时间"
        timestamptz finished_at "结局时间 可空"
    }
    agent_attempt {
        uuid id PK "每次执行尝试"
        uuid run_id FK "所属运行"
        uuid step_id FK "逻辑步骤"
        int number "步骤内尝试编号"
        uuid execution_epoch "派发执行权"
        text status "prepared dispatched completed failed incomplete canceled unknown"
        bytea input_content "实际输入密文"
        bytea output_content "完整观察或输出密文 可空"
        text output_sha256 "输出摘要 可空"
        jsonb receipt "工具调用ID 绑定 分配ID 批次 清理及结果合同"
        jsonb budget_receipt "占额 实际用量 未确认量及计时"
        int delivery_no "父流程结果交付顺序 可空"
        timestamptz created_at "预登记时间"
        timestamptz dispatched_at "受理派发时间 可空"
        timestamptz finished_at "结局时间 可空"
        text error_code "安全错误码 可空"
    }
```

- Tool binding 唯一 `(run_id,alias)`；声明与策略不可变。目录包含本次可用内置/Workflow/Skill/MCP 项，凭据通过 config_ref 当前读取。
- Step 唯一 `(run_id,node_key)`、`(run_id,ordinal)`；宿主调用唯一 `(parent_step_id,call_ordinal)`。父步骤、工具项必须属于同 Run。树父先于子创建，禁止环。accepted_attempt 与 step 同属关系使用延迟复合 FK，完成状态必须有 accepted_attempt。
- Attempt 唯一 `(step_id,number)`；每 Step 仅一条活动尝试的部分唯一索引。并行的是不同子 Step。接受过的结果不可覆写，Retry 新建 number。
- 工具 receipt DTO 包含 toolCallId、toolIndex、batchId、groupId、bindingKind、allocationId、externalRequestId、cleanup、effectStatus、artifactIds、安全错误；模型类 receipt 包含 modelCallIds，Workflow 类包含 runnerVersion 与 childStepIds。完整参数/结果在密文，公开摘要在事件。
- Workflow definition_snapshot 冻结 source/scriptSha256/entryVersion、输入摘要、logicalTime、randomSeed、Skill 文本及资源摘要。输入正文仍在 Attempt。交付顺序在同父 Step 锁内分配，保存结果和 delivery_no 后再送 QuickJS；重放按原顺序消费。后台资源清理可以继续更新 receipt 中的清理段，同时追加公开状态事件，已接受业务结果不变。

## 4. 关键 Outbox、Checkpoint 与命令

高频流式包仅存 Redis Streams，数据库新增表使用 `agent_outbox`，替代前版的全量 `agent_event`。每个关键业务事务写一条 Outbox，其 payload 可以包含多个公开包；文本 delta 不创建 Outbox 行。

```mermaid
erDiagram
    agent_run ||--o{ agent_outbox : publishes
    agent_run ||--o{ agent_checkpoint : saves
    agent_outbox ||--o| agent_checkpoint : marks
    agent_session ||--o{ agent_command : deduplicates
    agent_outbox {
        uuid id PK "关键批次标识 包ID由此派生"
        uuid run_id FK "所属Run"
        bigint run_version "本次业务提交版本"
        uuid request_id "原命令标识"
        uuid operation_id "业务提交幂等键"
        text operation_sha256 "本次提交摘要"
        jsonb payload "有类型公开包草稿数组 不含seq"
        text last_stream_id "投影完成后的批次尾ID 可空"
        timestamptz created_at "业务提交时间"
        timestamptz delivered_at "整批投影提交时间 可空"
    }
    agent_checkpoint {
        uuid run_id PK,FK "所属运行"
        bigint number PK "Run内版本"
        int schema_version "载荷Schema版本"
        uuid boundary_outbox_id FK "同事务关键边界"
        jsonb position "下个节点及Workflow调用位置"
        jsonb completed_refs "已接受Step与Attempt引用"
        jsonb message_refs "顺序化上下文Message引用"
        jsonb tool_binding_refs "原工具目录引用"
        jsonb artifact_refs "必需产物引用"
        jsonb plan_state "Todo ID与版本及状态"
        bytea verifier_state "验证事实及观察密文"
        jsonb budget_state "限额 消耗 占额 活跃时长"
        jsonb pending_calls "未决调用与结局核对要求"
        bytea continuation_state "必要模型私有续接密文 可空"
        text state_sha256 "规范快照摘要"
        timestamptz created_at "提交时间"
    }
    agent_command {
        uuid id PK "内部命令标识"
        uuid tenant_id "租户逻辑标识"
        uuid workspace_id "工作区逻辑标识"
        uuid actor_user_id "发起人逻辑标识"
        uuid request_id "客户端幂等键"
        uuid session_id FK "原子提交后所属会话"
        uuid run_id FK "目标或产生的Run 可空"
        text kind "submit reset pause resume cancel decision reconcile"
        text request_sha256 "规范命令摘要"
        jsonb response "原受理回执"
        timestamptz created_at "受理时间"
    }
```

- Outbox 唯一 `(run_id,operation_id)`、`(run_id,run_version)`；待投递部分索引 `(run_id,run_version) WHERE delivered_at IS NULL`。关键事务在 Run 行锁内递增业务版本，发布按该顺序串行执行；同 operation 不同摘要拒绝。仅内部状态变化可不生成公开 Outbox，版本无需连续。
- payload 为 `{protocolVersion:2, packets:[{packetId,requestId,occurredAt,event}]}`；packetId 由 Outbox ID 与包下标稳定派生，event 使用唯一公开联合，全部通过 Schema/大小校验。不包含私有上下文、完整工具观察或口令。
- `last_stream_id` 与 `delivered_at` 同有同无；只有整批事件已进入 Redis、完整公开投影与 projected_seq 在同一事务提交时才填写。已投递行保留关键操作回执以便幂等，数量随业务边界增长。
- PostgreSQL 不维护 Redis 最新流尾。Run.projected_seq 只表示已落库的完整展示前缀，连同公开消息/public_view 原子更新；流尾通过 Redis 查询。原生 ID 按两个整数比较，不使用 SQL 序列或额外 Session 计数。
- Checkpoint `(run_id,number)` 主键；Run.checkpoint_no 通过复合延迟 FK 指向它。boundary_outbox_id 使用同 Run 复合 FK，关联同一事务的公开变化；无需在数据库事务中等待 Redis 分配 ID。引用的 Message、工具、产物、Step/Attempt 必须逐项验证归属和有效性。
- Checkpoint JSON 明确结构：position 包含 rootStepId/nextNode/workflowHostOrdinal；completed_refs 为 stepId/attemptId/outputDigest；message_refs 按实际输入顺序保存 ID；预算保留原限额、已确认消耗、未知占额和剩余活跃时长。plan/verifier 复用前课有类型模型，统一加入 schemaVersion。
- Command 唯一 `(tenant_id,workspace_id,actor_user_id,request_id)`；同键同摘要返回原 response，其他输入 409；初次 submit 的 Session/Run/消息、初始投影、Outbox 与命令同事务写入。失败校验不写成功回执。

Redis 使用每 Run 一条 `compass:agent:run:<runId>:events` Stream，条目字段及保留规则见 Redis 数据合同。Message 从数据库编码完整 upsert 包，Run 从 Redis 编码增量，两者共同使用 AgentResponse。

## 5. 模型调用与真实尝试

`model_call` 原有字段及约束保留，真源为 models/entities.py。原字段包括 call_id、provider_id、config_version、binding_version、requested_model、response_model、purpose、actor_user_id、tenant_id、workspace_id、capability_summary、status、started_at、deadline_at、finished_at、duration_ms、execution、usage、error_code、upstream_request_id、upstream_outcome_unknown。

新增列如下；与全部既有字段共同构成目标模型：

| 字段               | 类型/可空                        | 含义                                                    |
| ------------------ | -------------------------------- | ------------------------------------------------------- |
| run_id             | uuid NULL FK                     | Agent Run 关联；独立模型测试/旧调用可空                 |
| agent_attempt_id   | uuid NULL FK                     | 对应 Agent 步骤尝试，与 run_id 同有同无，复合 FK 验归属 |
| input_message_refs | jsonb NULL                       | 原调用实际使用的有序消息 ID                             |
| request_content    | bytea NULL                       | 必要规范请求快照，密文，不含 API key                    |
| output_content     | bytea NULL                       | 必要规范返回与协议状态密文                              |
| content_status     | text NOT NULL，默认 not_captured | captured / not_captured，旧调用保留事实                 |

```mermaid
erDiagram
    model_call ||--o{ model_attempt : tries
    model_attempt {
        uuid id PK "原真实Attempt标识"
        uuid call_id FK "逻辑调用"
        int number "逻辑调用内编号"
        uuid provider_id FK "本次实际Provider"
        int config_version "配置版本"
        int binding_version "协议绑定版本"
        text requested_model "本次请求模型"
        text status "prepared dispatched completed failed canceled incomplete unknown"
        text origin "live或legacy_summary"
        bytea request_content "本次实际规范输入密文 旧记录可空"
        bytea output_content "本次输出及协议结果密文 可空"
        text output_sha256 "输出摘要 可空"
        boolean sent "已开始上游派发 默认false"
        boolean outcome_unknown "上游结局未知 默认false"
        boolean cleanup_confirmed "清理回执 默认false"
        jsonb usage "实际用量或未知字段"
        bigint reserved_tokens "保守Token占额"
        bigint reserved_cost_microusd "保守成本占额"
        bigint actual_cost_microusd "实际成本 可空"
        text upstream_request_id "上游标识 可空"
        text error_code "安全错误 可空"
        timestamptz created_at "预登记时间"
        timestamptz dispatched_at "派发时间 可空"
        timestamptz finished_at "结局时间 可空"
        bigint duration_ms "实际耗时 可空"
    }
```

唯一 `(call_id,number)`，索引 `(call_id,created_at)`、`model_call(run_id,started_at)`。先保存 prepared/占额，再将派发意图写为 dispatched，随后外呼；崩溃在派发意图与网络发送之间也保守标未知。逐次返回即保存，最后生成原 execution 聚合。恢复不得将 unknown 改成零消耗。

旧 execution 可解析的 Attempt 使用原 ID；缺 ID 时以 call_id+number 确定性派生并标 legacy_summary，保留其实际已知字段。旧记录未记占额的迁移填 0 仅表示“历史无预留记录”，不得作为待恢复预算；旧调用不进入新 Run 恢复。原 execution 原样保留供历史核对。

## 6. 产物与 Workflow 草稿

```mermaid
erDiagram
    agent_attempt ||--o{ agent_artifact : produces
    agent_run ||--o{ agent_workflow_draft : offers
    agent_artifact {
        uuid id PK "原Artifact ID"
        uuid run_id FK "所属运行"
        uuid attempt_id FK "来源尝试"
        text tool_call_id "原工具调用标识"
        text name "安全文件名"
        text media_type "内容类型"
        bigint size_bytes "字节数"
        text sha256 "字节摘要"
        jsonb scope "原授权数据范围"
        bytea content "持久原字节"
        timestamptz created_at "接收时间"
    }
    agent_workflow_draft {
        uuid id PK "原保存邀请标识"
        uuid run_id FK "来源运行"
        uuid step_id FK "通过校验的流程步骤"
        text suggested_name "建议名称"
        text script_source "已验证源码"
        text script_sha256 "源码摘要"
        int definition_version "定义版本"
        int runner_api_version "运行入口版本"
        jsonb validation_summary "来源案例及执行结论"
        text status "offered saved expired"
        uuid asset_id FK "保存后的workflow_asset 可空"
        timestamptz created_at "邀请时间"
        timestamptz expires_at "邀请截止时间"
        timestamptz saved_at "保存时间 可空"
    }
```

Artifact 校验 `size_bytes=octet_length(content)`、允许 media type、M4 上限及应用 SHA-256。ID 全局唯一；同 ID 同来源同摘要重放复用，冲突拒绝；索引 `(run_id,created_at)`。本课 PNG/CSV 量级直接 bytea 原子提交。

Draft 的 step 必须同 Run 且已成功，唯一 `(run_id,step_id)`；saved 状态必须有 asset_id/saved_at，assetId 唯一。原 workflow_asset 不复制。邀请过期由控制读取/保存请求按数据库时间判断，更新 expired 并发事件；刷新展示同时读取持久 expiresAt，禁用保存。原草稿 30 分钟 TTL 转为绝对时间，进程重启不刷新有效期。

## 7. HITL 增量实体

```mermaid
erDiagram
    agent_run ||--o{ agent_wait : parks
    agent_wait ||--o| agent_action : approves
    agent_action ||--o| agent_demo_effect : applies
    agent_wait {
        uuid id PK "稳定等待点"
        uuid run_id FK "原Run"
        uuid step_id FK "待派发步骤"
        bigint checkpoint_no FK "原等待边界"
        text kind "approval external_event reconciliation"
        uuid proposal_id "提案标识"
        int proposal_revision "提案版本"
        text proposal_sha256 "规范提案摘要"
        jsonb public_proposal "动作 影响 范围 参数摘要"
        bytea private_proposal "完整待派发参数密文"
        jsonb expectation "所需权限或受信事件关联"
        text status "pending approved rejected expired canceled"
        uuid decision_id UK "已消费决定 可空"
        uuid decider_user_id "决定主体 可空"
        timestamptz created_at "等待建立时间"
        timestamptz expires_at "决定截止时间 核对等待可空"
        timestamptz decided_at "决定时间 可空"
    }
    agent_action {
        uuid id PK "稳定Action ID"
        uuid run_id FK "所属Run"
        uuid wait_id FK,UK "批准的等待点"
        uuid step_id FK "受控动作步骤"
        text proposal_sha256 "批准参数摘要"
        text state "pending applied unknown denied"
        jsonb receipt "可核对效果回执 可空"
        timestamptz created_at "动作预登记时间"
        timestamptz updated_at "最后核对时间"
    }
    agent_demo_effect {
        uuid action_id PK,FK "唯一生效动作"
        text campaign_key "合成广告活动"
        bigint delta_cent "合成预算变更分"
        text proposal_sha256 "实际应用参数摘要"
        timestamptz committed_at "效果提交时间"
    }
```

Wait 索引 `(run_id,status)`、pending 的 `(expires_at,id)`；一 Run 一个当前 pending 等待点，串行处理多个需审批提案。绑定 step/checkpoint/action 均通过 run_id 复合约束；proposal_revision>0；approval/external_event 要求 expires_at>created_at，reconciliation 允许无截止时间。approved/rejected 必须有 decision/decider/time；expired/canceled 无用户决定。过期核验采用数据库当前时间。

Action 唯一 wait_id，预先生成 ID 不随 Retry 改变；effect 与批准摘要一致。演示 effect 使用独立短事务写入，回执事务可后到，便于核对真实提交后崩溃。具体门禁、授权和竞态见 HITL_DESIGN。

## 8. 生命周期、旧数据和交付清单

新增 15 张表：11 张 Agent 运行主线表、model_attempt、3 张 HITL 表；扩展 model_call。计划/Verifier/节点/脚本有明确承载位置，MCP 配置和 Sandbox 分配复用 0008，已保存 Workflow 复用 0007。

会话、消息、公开展示投影、步骤、调用和产物持续保留。Redis Stream 为短期 Run 增量日志：非终态按原 Run 总量预算保留且不设 TTL；终态投影到流尾、Outbox 全部投递后设置 1 小时整键过期，Message 加载保持可用。agent_outbox 保留少量关键操作及投递回执。终态后清除 continuation_state 及模型输出中同用途的私有续接段，不删公开历史和可核对结果。活跃 HTTP/MCP 会话、内存锁/Task、Sandbox 进程和临时路径只重建或清理；它们的身份与结局记录入库。

迁移必须验证：同 Run/Session 复合归属、终态/状态 CHECK、活动 Run/Attempt 部分唯一、原模型 scope CHECK、旧 execution 的可确定回填、原资产/连接保留、M4 遗留资源清理记录保留、运行角色权限、真库原生链与 SQL 一致性及备份恢复。当前未存在的历史 Session 和消息没有回填来源，升级后首个持久请求开始新历史。

发布、增量文件路径和恢复顺序以[主方案第 6 节](TECH_DESIGN.md)为准。可执行迁移和 ORM 只在 app 中实现，本文件中的 ER 与字段合同用于评审。


## 第 19 课 · Redis 流与本地 Docker 部署

[返回主方案](TECH_DESIGN.md) · 数据结构 · 代码设计 · [PRD](PRD.md)

> 2026-11-12 · 用户已确定引入本地 Docker Redis。以下为待实施设计，尚未修改 Compose、安装客户端或启动容器。

## 1. 存储分工

本课采用 **PostgreSQL 持久业务数据 + Redis Streams 短期增量 + 数据库完整展示投影**。Redis 为运行必需依赖，使用 Compass 基础 Compose 中的独立实例；与 observability 等其他用途的 Redis 分离。单 Agent 实例负责写流、投影和读取，不引入独立投影服务、消费组、集群、Sentinel 或任务队列。

| 内容                                                          | 写入位置与时机                                 | 读取用途                                 |
| ------------------------------------------------------------- | ---------------------------------------------- | ---------------------------------------- |
| Session、原问题、运行配置、命令幂等                           | 受理事务写 PostgreSQL                          | 会话列表、首问恢复、重复请求             |
| 文本 delta、实时公开对象更新                                  | 合并后写 Redis；持久确认后对外输出             | Run SSE、断线续传、待落库投影            |
| 完整公开消息、Run 展示头、过程对象                            | 每 500 ms 或 64 KiB 合并投影；关键边界强制提交 | Message JSON、侧栏状态、完成后的全部历史 |
| Step/Attempt、上下文、预算、Checkpoint、Wait/Action、产物字节 | 按执行边界直接写 PostgreSQL                    | 执行恢复、审批、效果核对、下载           |
| 关键公开变化的待发布批次                                      | 与业务变化同事务写 agent_outbox                | SQL 提交后 Redis 发布失败的补发          |

事件指业务数据包；SSE 心跳、注释和 HTTP 网络分片不存储。高频文本不建立 SQL 事件行。agent_outbox 保留创建、步骤结果、控制、审批和终态等关键操作的发布载荷及回执。

## 2. 流键与游标

| 项           | 合同                                                                                         |
| ------------ | -------------------------------------------------------------------------------------------- |
| 键           | `compass:agent:run:<runId>:events`；每 Run 一条 Stream                                       |
| ID           | `XADD *` 产生原生 `毫秒-序号` 字符串，起点 `0-0`，仅在当前 Run 内排序                        |
| 必需字段     | `packetId`、`requestId`、`occurredAt`、`event`（校验后的 JSON）                              |
| 关键批次字段 | `outboxId`、`batchIndex`、`batchSize`；普通 delta 无这些字段                                 |
| 公开响应     | Redis ID 编码为 AgentPacket.seq；内部批次字段不进入前端协议                                  |
| SQL 投影位置 | `agent_run.projected_seq`；与消息和 public_view 在同一事务提交                               |
| 活跃流       | created/running/waiting/paused/cancelling 及终态投影未完成期间无 TTL，无 MAXLEN/XTRIM        |
| 终态流       | 投影追到流尾、Outbox 全部投递后，整键 EXPIRE 3600 秒                                         |
| 容量         | 遵守现有单帧/单 Run 预算，Redis 总量默认 maxmemory 256mb、noeviction；关键收口包计入预留预算 |

每个浏览器按自己的 `after` 使用 XREAD/XRANGE 读取，不使用分摊消息的消费组。Redis ID 的两段分别按整数比较；没有 `seq+1` 的连续性要求。稳定 packetId 识别发布重试；对象 revision 识别重复更新。浏览器游标在整帧应用成功后推进。

活跃流禁止局部裁剪，因此 `after` 必须是 `0-0` 或该 Run 的真实保留 ID；伪造、超前的游标返回 `cursor_invalid`。只有公开投影已终态且 Outbox 全部投递时，缺失流才按保留期结束返回 `history_reload_required`，前端重载 Message 即可。活跃流缺失、流尾落后于 SQL 投影或关键批次不完整时停止自动续接；普通未完成批次先由 Outbox 补齐。经核对确认数据丢失后标记 recovery_required，保留已存历史，避免循环重载和静默跳过内容。

同一 Run 的流只初始化一次。提交已受理但首批 Outbox 尚未投递、projected_seq 仍为 `0-0` 时可以初始化；首批投影完成后才允许模型/工具派发。此后缺失的活跃流进入恢复核对，禁止创建同名空流直接推进。本课无需额外的 Session 流序号、Redis INCR 计数或流代际字段。

## 3. 发布、投影与一致性

每 Run 使用一个进程内串行发布通道，前序 delta、关键 Outbox 和后续内容保持顺序。持有本课既有单实例执行权的 Agent 才能发布；所有者连接失效即停止发布和派发。多实例接管由后续课程扩展。

**高频增量：** 模型回调 → 50 ms/8 KiB 合并 → XADD → AOF 持久确认 → SSE。Projector 从 projected_seq 之后读取，按同一业务 reducer 形成完整消息和 public_view，每 500 ms 或累计 64 KiB 提交；阈值达到任一个即尝试刷新。投影失败施加背压并停止后续派发，保留 Redis 尾部。Redis 连接与写入无法确认时不放行该包。

**关键变化：** PostgreSQL 原子保存业务状态和 Outbox → 提交后 Publisher 写 Redis → Projector 强制提交完整关键批次及之前的增量 → 放行该批次 SSE。等待/暂停、审批变化、产物可用、消息完成和 Run 终态都走此路径。控制入口的受理回执可以先返回，前端业务视图仍由共享协议更新。HITL 效果查询与已返回结果的保存允许继续，新的外部派发等待依赖恢复。

Outbox 的所有包使用固定 ID、原时间和内容摘要；一次批次发布期间不交错其他写入。部分 XADD 成功后连接中断，先查该有界流中的包 ID/摘要，补齐缺项；不能把第一次失败直接认定为未写入。Redis 客户端对非幂等写命令关闭自动重试，读取可以有限重试。高频包也复用原 packetId 确认结果。无法核对时停止通道，原记录留待恢复。

Projector 按 Stream ID 顺序处理，只提交完整关键批次；最后一个 batchIndex 到达前可以先提交它之前的普通增量。整批公开消息、public_view、projected_seq 与 Outbox.delivered_at/last_stream_id 在同一 SQL 事务提交。Projector 重启从 SQL 游标继续；已处理 packetId/revision 不重复追加。SSE 对普通增量读取已获持久确认的前缀，对关键批次还需等待投影游标覆盖批次末尾。启动先核验 Redis 持久流和 SQL 游标，再以恢复后的流尾重建进程内确认位置，随后补发 Outbox、补投影并开放执行；无需逐包回写 SQL。

public_view.run 保存与该投影前缀一致的运行展示头。Message 的 Run 状态、消息和过程都从这一读取模型编码；业务控制表先变为 completed 时，尚未投影的完成状态不会提前出现在 Message 或侧栏。Run SSE 只在终态投影完成、关键 Outbox 全部投递且尾部送达后正常结束。下一轮提问同时检查前轮终态与投影完成。

## 4. 本地 Docker 配置

以下片段拟合并到 `deploy/compose/compose.yaml`，保留现有 postgres、migrate、agent 及其他服务。Redis 无 app profile，供本机开发与完整容器部署共用。

```yaml
services:
  redis:
    image: redis:8.2.11-alpine
    restart: unless-stopped
    command:
      - redis-server
      - /usr/local/etc/redis/redis.conf
      - --requirepass
      - ${COMPASS_REDIS_PASSWORD:-compass_redis_local_only}
    environment:
      REDISCLI_AUTH: ${COMPASS_REDIS_PASSWORD:-compass_redis_local_only}
    ports:
      - "127.0.0.1:56379:6379"
    volumes:
      - redis-data:/data
      - ../redis/redis.conf:/usr/local/etc/redis/redis.conf:ro
    mem_limit: 768m
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 2s
      timeout: 3s
      retries: 30

volumes:
  redis-data:
```

拟新增 `deploy/redis/redis.conf`：

```conf
bind 0.0.0.0
protected-mode yes
dir /data
appendonly yes
appendfsync always
no-appendfsync-on-rewrite no
save ""
maxmemory 256mb
maxmemory-policy noeviction
```

本地采用固定版本标签；实施锁定镜像摘要并同步部署清单。命名卷保存 AOF 数据，Redis 内存上限之外保留容器缓冲及 AOF 重写余量。AOF always 的每批写入持久确认是本方案的发送门禁；维持 50 ms/8 KiB 合并控制刷盘频率。配置选择参照 [Redis 持久化说明](https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/)和[官方镜像](https://hub.docker.com/_/redis)。运行中不得自行降为 everysec 后继续承诺相同的已展示内容恢复边界。

现有 `agent` 服务拟增补以下 environment / depends_on，保留原有迁移依赖与其他配置；Compose 对 `service_healthy` 的等待见[启动顺序说明](https://docs.docker.com/compose/how-tos/startup-order/)。

```yaml
services:
  agent:
    environment:
      COMPASS_REDIS_URL: redis://redis:6379/0
      COMPASS_REDIS_PASSWORD: ${COMPASS_REDIS_PASSWORD:-compass_redis_local_only}
    depends_on:
      redis:
        condition: service_healthy
```

根 `.env.example` 拟新增宿主机开发值：

```dotenv
COMPASS_REDIS_URL=redis://127.0.0.1:56379/0
COMPASS_REDIS_PASSWORD=compass_redis_local_only
```

URL 与口令分别传给客户端，避免 URL 编码和日志混入口令。示例口令仅用于本地开发；Redis 宿主端口绑定回环地址。Agent 容器显式使用服务名 redis，保持与宿主机 URL 分开。Web/BFF、浏览器和 Memory 不读取这两个变量。

Agent 使用 `redis` Python 包的 asyncio 客户端，安装版本随 `uv.lock` 固定。设置连接/读写超时、有限连接池，普通命令和阻塞 XREAD 使用分开的池，避免浏览器订阅耗尽写入/投影连接。仅新增 URL/口令配置，批次阈值、TTL 和容量先采用本文默认值，满足真实需要后再增加配置项。

## 5. 启动、停止与故障

实施后的本机启动顺序如下；当前 `pnpm db:up` 仅启动 postgres，保持该语义。本次新增依赖使用已有 Docker Compose 命令，无额外根命令别名。

```bash
pnpm db:up
docker compose -f deploy/compose/compose.yaml up -d --wait redis
docker compose -f deploy/compose/compose.yaml exec -T redis redis-cli ping
docker compose -f deploy/compose/compose.yaml exec -T redis redis-cli CONFIG GET appendfsync
pnpm dev -F agent
```

完整本机部署仍走 `pnpm run deploy`，Agent 的 Redis 健康依赖保证启动顺序。`pnpm db:down` 当前调用整个 Compose down，增加 Redis 后也会停止该实例，命名卷继续保留；部署说明须同步这个影响。临时仅停 Redis 可使用 `docker compose -f deploy/compose/compose.yaml stop redis`。不在常规清理中使用 `down -v` 或 FLUSHALL。

Agent `/healthz` 检查进程；持久执行 `/readyz` 校验数据库、Redis ping/AOF 配置和执行所有者。Redis 不可用时新 Run 提交/恢复返回可重试的依赖不可用错误，Message 仍可从 PostgreSQL 读取已提交历史，控制决定继续按数据库事务记录。依赖恢复后先补发和投影，再接受新的执行派发。

| 故障或操作                       | 约定结果                                                                                      |
| -------------------------------- | --------------------------------------------------------------------------------------------- |
| 浏览器断网、刷新、切换           | 原 Run 继续；从最后已应用 ID 补读，执行任务与连接独立                                         |
| Agent 在 XADD 前退出             | 未确认包不发送；恢复已持久业务边界，未知模型结局按原规则核对                                  |
| Agent 在 XADD 后、投影前退出     | Redis AOF 保留已确认包；重启从 projected_seq 补投影，再公开恢复状态                           |
| SQL 关键提交后 Redis 发布失败    | Outbox 保留原批次；不发布该成功状态、不派发下一步骤，恢复后补齐                               |
| 投影 commit 后回执/网络中断      | SQL 游标及投递回执原子保留，重复处理幂等，Message 可直接读取                                  |
| Redis 进程/容器重启，原卷完整    | AOF 恢复已确认记录；Agent 重连、补投影，已完成调用不重跑                                      |
| Redis 不可用、内存写满或磁盘错误 | 无成功写确认则不发送；停止新派发，已到达结果存 SQL/Outbox，依赖恢复后续处理                   |
| 终态流过期                       | Message 独立恢复完整结果，运行中最后视图与刷新视图相同                                        |
| 活跃流缺失、AOF 损坏或数据卷丢失 | 保留 SQL 最近投影与关键业务记录，标记恢复受阻；未投影尾部可能无法找回，禁止静默自动重建并续跑 |

本课保证正常进程/容器重启且卷完整时的恢复。单机 AOF 不覆盖磁盘永久丢失；上述损坏边界必须明确报告。若 Redis 服务仍故障，读取保留历史即可，Run 接口返回可重试错误；发现已确定的数据缺失时返回 `stream_data_lost`，客户端只重载一次 Message 并显示恢复受阻，避免重复刷新循环。

## 6. 实施与验收接缝

落地修改 Compose、redis.conf、根环境示例、Agent settings/依赖/连接池、lifespan、readyz、redis_stream/outbox_publisher/public_projection 以及部署文档。PostgreSQL 迁移仍为 agent/main 的 0008 → 0009，字段合同在 DATA_DESIGN 唯一维护；Redis 无独立 SQL 迁移。

验收归 PRD AC-10、AC-11、AC-17、AC-19：真实 Redis/SQL 下验证发布和投影各故障窗口、容器保卷重启、noeviction 写满、Outbox 部分发布恢复、终态过期后 Message 还原及双接口同 Schema。验证使用隔离测试 Run/Compose 项目，不清空共享 Redis 或删除现有卷。额外检查数据库行数随业务边界增长，长文本增量只更新消息投影，不产生等量 Outbox 行。


## 第 19 课 · Human in the Loop 增量方案

> Feature 985 · Profile `standard` · 待评审 · 2026-11-12 · 增量基线为本课持久化主方案及第 18 课工具策略。

[返回主方案](TECH_DESIGN.md) · [PRD](PRD.md) · 字段合同 · 代码设计 · [HTML 审阅版](HITL_DESIGN.html)

## 1. 增量目标与接入位置

本方案承接 FR-04～FR-06 和 AC-02～AC-06，完整实现人工决定、持久等待、原 Run 接续与动作核对；展示同时遵守 AC-09～AC-11 的刷新一致性。

前置 M4 提供 `ToolPolicy(effect, approval)`、派发入口、执行回执和资源清理。本次把 `approval=required` 的阻断接为可操作的持久等待：冻结提案，保存 Checkpoint，释放执行资源；用户作出决定后从同一 Run 继续。M3 的等待节点同样调用此服务。审批状态通过共享 AgentResponse 中的 view.upsert 表达；Run 接口实时推送，刷新通过 Message 非流式加载同一审批对象。

```mermaid
flowchart TB
    H["Harness / Workflow"] --> D["Tool Dispatcher · 策略预检"]
    D --> Q{"approval required"}
    Q -->|否| T["现有受控工具执行"]
    Q -->|是| W["持久化提案 / Wait / Checkpoint"]
    W --> DB[("Agent PostgreSQL")]
    DB --> P["Outbox → Redis → 强制投影"]
    P --> UI["Message JSON / Run SSE · 同一审批对象"]
    UI --> C["BFF · CSRF 与当前身份"]
    C --> A["Agent · 决定与状态事务"]
    A --> R["核验权限 / 原参数 / 已知效果"]
    R --> T
    T --> DB
```

仅新增 `agent_wait / agent_action / agent_demo_effect`，完整字段在 DATA_DESIGN；共享 Run、Step/Attempt、Command、Outbox、Redis 流、Checkpoint 和 Artifact。迁移随 0009 一起交付，HITL 可作为独立代码切片验收。

## 2. 提案与等待

提案包含 `runId, waitId, stepId, proposalId, proposalRevision, proposalDigest, actionId`、动作类型、作用对象、公开参数摘要、实际参数密文、所需权限和 `expiresAt`。Action ID 在提案时确定：以 waitId 和 proposalRevision 确定性派生，批准后插入 Action，重试和恢复保持原值。

本课支持明确的“批准原提案”或“拒绝”。用户修改参数需要新提案和新等待点，关闭旧提案；旧批准不覆盖新参数。课堂审批有效期 15 分钟，使用数据库时间，服务重启不重新计时。首版每 Run 串行处理一个当前等待点；同批多个需审批动作按原工具顺序逐个等待。

到达门禁时执行同一事务：

1. 锁 Session、Run、目标 Step，检查原执行权、状态、当前授权范围和提案摘要。
2. 保存已完成结果、必要产物及 Checkpoint，创建 Wait，把待派发 Step 标 waiting，Run 标 waiting。
3. 同事务写入含 `view.upsert` 和 `run.upsert` 的关键 Outbox，释放 execution epoch。提交后 Publisher 写 Redis，Projector 强制保存整批审批/节点/Run 投影及游标，再允许流展示。
4. 提交后释放本次模型/工具执行槽和 MCP 会话，按 M4 清理计算资源。工作卷与已接收产物按各自策略保留；清理失败保存回执并禁用后续 Resume，等待核对。

等待期间仅持久记录存在，UI 订阅和应用级小型到期检查可以继续运行。原工具调用尚未派发。资源清理属于结果可观察的一部分，不能只结束 Python 协程便显示清理完成。

## 3. 决定与接口

| 接口                                             | 合同                                                                                                                       |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| `POST /v1/analysis/runs/{runId}/decisions`       | `requestId, expectedVersion, waitId, proposalId, proposalRevision, proposalDigest, decisionId, decision=approve 或 reject` |
| `GET /v1/analysis/runs/{runId}/waits/{waitId}`   | 为获授权审批人返回安全提案和当前决定；不返回私有上下文或整个会话                                                           |
| `POST /v1/internal/analysis/runs/{runId}/events` | 受信外部事件入口，专用服务身份；`eventId, waitId, eventType, correlationKey, payload`                                      |
| `POST /v1/analysis/runs/{runId}/reconcile`       | requestId、expectedVersion、waitId、actionId；显式核对原效果，不授予新效果权限                                             |

BFF 转发用户控制命令前校验会话/CSRF/当前 scope；Agent 校验内部委托及资源归属。审批人沿用现有有效租户管理员和当前工作区 `models.invoke` 权限组合，无新增 Web 权限表迁移；拥有两项资格的发起人可以批准自己的课堂提案。普通分析员可查看自己的待决状态并拒绝/取消自己的 Run，批准仍要求上述资格。其他工作区管理员无权批准。应用角色的实际映射在实施时复用 Web 既有权限解析函数。

决定处理：先核验当前请求人权限，再检查同 requestId/decisionId 的原回执。相同决定返回原结果，参数不同返回 409。首次决定锁定 Wait/Run，检查 pending、版本、范围、摘要和 expiresAt；批准同事务消费 Wait、登记 Action、转换 Run 为 running 并分配新 epoch，记录审批/运行变化的关键 Outbox。提交后登记应用级执行任务，等待 Redis 发布及整批投影完成后再派发获批动作；提交后任务未启动即退出，按主方案恢复原 Run。

有效拒绝或当前提案到期关闭动作分支，使用已保存只读分析形成最终结果和关闭原因，Run 收口 completed；无需再调用模型补一句结论。动作 Step 标 canceled，保留原因。显式取消整个任务收口 canceled，保留已提交内容。旧请求错配或越权返回 404/403，冲突 409，不消费等待点；过期提案返回 409 `approval_expired` 并确保过期状态已记录。

到期由 Agent lifespan 的有界扫描处理 pending approval（每秒一批），启动时补扫，决定入口也在事务内判定到期。Waiting 的相同 Run 行锁裁决批准与到期竞态。外部事件等待按配置的类型和关联键消费，独立于用户审批。reconciliation 等待不因定时到期重新执行动作，保留未决结局。

## 4. 控制状态与竞态

```mermaid
stateDiagram-v2
    [*] --> created
    created --> running: 开始
    running --> waiting: 持久提案或效果未知
    running --> paused: 边界暂停或重启待恢复
    waiting --> running: 有效决定或受信事件
    waiting --> completed: 拒绝或审批到期
    paused --> running: 显式Resume
    running --> completed: 成功提交
    running --> failed: 明确失败
    created --> cancelling: 取消
    running --> cancelling: 取消
    waiting --> cancelling: 取消
    paused --> cancelling: 取消
    cancelling --> canceled: 已清理及核对
```

| 操作          | 处理                                                                                                                                              |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| Pause         | Running 记录 control_intent=pause；当前安全步骤结算后存 Checkpoint 转 paused。正在执行的外部动作先取得或核对回执，不回滚已生效效果。              |
| Resume        | 只从可恢复的 paused 或已满足条件的 waiting 取得新 epoch；校验 Checkpoint、权限、版本、产物和未决调用。pending approval 返回 `decision_required`。 |
| Cancel        | 原子标 cancelling，禁止后继派发；未派发的 Wait 标 canceled。正在执行资源按 M4 清理；结局未明继续 cancelling/cleanup_unconfirmed 并可查询。        |
| 重复决定/控制 | 同 requestId 同输入返回原回执；新 requestId 使用过期 expectedVersion 返回冲突并要求读取最新状态。                                                 |
| 批准与取消    | 共用 Session/Run 行锁。取消先提交，批准失效；批准先提交，实际效果提交前仍再次检查取消。                                                           |
| 终态后 Resume | 拒绝，保留原终态和事件。重新分析创建新 Run。                                                                                                      |

现有 `cleanup_unconfirmed` 表达为清理结果，映射到新 Run 的 cleanup_status 与安全原因，待核对时不宣告资源已释放。v1 适配器维持其原终态包语义。

## 5. 动作核对与权限复查

```mermaid
sequenceDiagram
    participant U as 审批人
    participant A as Agent
    participant W as Web当前授权
    participant D as Agent主库
    participant E as 演示动作适配器
    U->>A: 原提案批准
    A->>W: 当前审批权限
    W-->>A: 允许
    A->>D: 消费Wait / 建Action / 恢复Run / 事件
    A->>E: lookup(actionId)
    alt 已有效果
        E-->>A: 原回执
        A->>D: 补记结果与事件
    else 确认无效果
        A->>W: 复查审批人和执行人权限
        W-->>A: 当前允许
        A->>E: apply(actionId, epoch, proposalDigest)
        E->>D: 独立短事务锁Run并核对取消，唯一效果写入
        Note over A,E: 夹具在效果提交后杀死进程
        A->>D: 另一次事务保存回执与完成结果
    else 无法确认
        A->>D: waiting / reconciliation
    end
```

执行前复查当前审批人资格、发起人分析权限、workspace 状态、原参数摘要、工具目录及依赖产物。授权与 Agent 数据分属不同服务，复查针对本次派发，返回后立即进入派发门禁；取消仍在 Agent 事务中线性裁决。不得声明跨库原子撤权。

课堂适配器在 agent/main 的独立事务保存 `agent_demo_effect`，锁顺序与运行事务一致。已存在 actionId 则校验同一提案摘要并返回原效果；新增时检查 epoch、当前状态和取消意图，唯一键保证同 Action 只生效一次。随后另一事务保存 agent_action receipt 和 Step/Run 状态。效果查询不产生新副作用，撤权后内部仍可补记既有回执；新效果必须重新获得当前权限。

对普通 MCP 的非幂等写操作，提交后失联只进入待核对，不承诺远端恰好一次。M4 的未知副作用策略继续生效。本课自动接续副作用的课堂验收使用可按 Action ID 查询的受控适配器。

## 6. 用户视图与刷新

审批卡片嵌入原执行树，绑定同一 nodeId/waitId。公开字段为动作、作用范围、参数摘要、有效期、允许的操作、决定状态与安全原因；完整参数、密文和授权委托不输出。用户按主 PRD 文案操作。

等待与决定先保存业务记录及关键 Outbox，再经 Redis 强制投影到 public_view 的审批对象。Redis 暂时不可用仍可按数据库事务受理批准/拒绝/取消，决定已受理期间保留同步状态，恢复发布与投影后才允许新增动作；等待计时不依赖 Redis TTL，waiting 流保持保留。Run 实时推送和 Message 非流式加载都返回同一 view.upsert，由相同 reducer 恢复按钮状态和提案修订。短期增量日志清理后，完整审批对象仍可读取。已到期但扫描尚未提交时，根据 expiresAt 禁用按钮并展示“确认已过期”，等待事件同步；服务端仍以数据库时间裁决。批准请求超时后用同 requestId/decisionId 查回原结果，禁止自动新建第二个决定。

## 7. 实施与验证

先完成持久化主方案的 T1～T4，再实现 runtime/hitl.py、Dispatcher 门禁和 Workflow 等待接缝；API/Schema 与前端卡片随 T5/T6 集成。数据模型和密文用途复用 DATA_DESIGN；所有状态事件走同一 Store，不另设 HITL 事件库或客户端 reducer。

必须覆盖：真实重启后批准与读取原图表；重复/过期/错配/撤权；暂停与取消竞态；动作已提交但回执丢失；效果未知；拒绝/到期的确定性只读结论；审批卡片刷新一致；等待资源释放；外部事件关联。模型/工具计数、实际字节与效果计数纳入业务断言。

实现和上述验证尚未执行。独立方案可与持久化主线分别评审，最终在同一案例矩阵验收。
