# 第 19 课学习资料

《企业级Agent工程架构实战营》 · 从内存循环到持久运行：构建 Run State、Checkpoint 与 Human-in-the-Loop

解压后双击 [TECH_DESIGN.html](TECH_DESIGN.html) 离线阅读。

- [PRD.md](PRD.md) 收录需求、业务规则和验收标准。
- [TECH_DESIGN.md](TECH_DESIGN.md) 收录技术正文与配套设计。

另可打开 [HITL_DESIGN.html](HITL_DESIGN.html) 阅读人工决策增量方案。
