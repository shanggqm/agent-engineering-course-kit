# 第 16 课 · 受控自主执行技术方案

《企业级Agent工程架构实战营》 · Compass Feature 988

[产品需求](PRD.md) · [离线阅读版](TECH_DESIGN.html)

## 目标

在第 15 课的同步 ReAct Run 上支持 Todo 规划与调整，独立验证零售分析的关键结果，并在轮次、工具、Token、费用与执行期限内结束。

## 整体架构

```mermaid 执行与终态
flowchart TD
    Chat["Chat 问题与本次约束"] --> API["Run API · 创建 RunControl"]
    API --> Loop["AgentExecutor · 同一 ReAct 循环"]
    Loop --> Model["模型决策 · Attempt 准入与结算"]
    Model --> Choice{"选择动作"}
    Choice -->|Todo| Plan["校验版本、依赖和状态"]
    Choice -->|查询| Query["授权 Retail · 只读执行"]
    Query --> Check["Verifier · 核对来源与覆盖"]
    Choice -->|关键结论| Verify["核对金额、排名和查询来源"]
    Plan --> Loop
    Check --> Loop
    Verify -->|可修订| Loop
    Verify -->|通过| Commit["RunControl 裁决终态"]
    Choice -->|普通回答| Commit
    Loop -->|额度、超时或取消| Commit
```

## Runtime 类型设计

```mermaid 规划、核验与预算
classDiagram
    AgentExecutor --> RunControl
    AgentExecutor --> ControlledRun
    AgentExecutor --> AgentState
    ControlledRun *-- ExecutionPlan
    ControlledRun *-- Verifier
    ControlledRun *-- AutonomyBudget
    ControlledRun *-- StopPolicy
    ExecutionPlan --> TodoDefinition
    Verifier --> RetailQueryResult
    AgentState *-- Step
    Step *-- ToolResult
```

| 对象 | 职责 |
| --- | --- |
| `AgentExecutor` | 路由、驱动模型循环、派发工具、回填观察以及提交候选结果。 |
| `ControlledRun` | 处理 Todo 动作与结构化结果提交，组织计划、核验与预算；通过扩展事件报告进度和停止原因。 |
| `ExecutionPlan` | 保存计划版本、事项、依赖与状态。模型调用 `todo_write` 建立、选择、完成或跳过事项。 |
| `Verifier` | 核对同一 Run 的真实查询、对比时段覆盖和结构化结论。校验反馈供模型重查或调整计划。 |
| `AutonomyBudget` | 在模型 Attempt 前预留 Token 与费用，在回执后结算；工具派发和模型轮次分别计数。 |
| `StopPolicy` | 识别重复查询、连续失败、无进展与证据冲突。 |
| `RunControl` | 处理期限、取消和资源清理，并统一裁决终态。 |

## 一次受控经营诊断

```mermaid 规划和核验时序
sequenceDiagram
    participant C as Chat
    participant A as AgentExecutor
    participant M as 模型
    participant R as Retail 与 Verifier
    C->>A: 提交问题和运行约束
    A->>M: 提供已注册工具
    opt 模型建立计划
        M->>A: todo_write replace
        A-->>C: 发布计划快照
    end
    M->>A: retail_sales
    A->>R: 校验权限后查询
    R-->>A: 行、覆盖标记和查询引用
    A->>M: 回填工具观察
    M->>A: submit_analysis
    A->>R: 核对来源、金额和排名
    alt 核验通过
        A-->>C: 已核验结论及可选商品 CSV
    else 可以调整
        A->>M: 核验反馈，继续受额度约束的循环
    end
```

临时查数走工作区 Retail 只读身份。工具支持列授权表、查看字段和执行受限单条 SELECT，结果最多 50 行、4 KiB。对比诊断保留按渠道及商品的专用查询与核验。

## 预算与课堂预置

```json 本次运行约束
{
  "plan": "required",
  "maxSteps": 2,
  "timeoutSeconds": 5
}
```

轮次可设为 1–20，时限可设为 1–180 秒。受控档默认 40 个工具动作、160,000 Token 和 500,000 微美元。配置档案缺失时模型出站前停止。付费档案由部署环境验收。课堂可编辑计划开关、轮次和时限；Run 状态保存在进程内，持久恢复由后续课次接入。

计划扩展事件驱动输入框上方的浮条，支持鼠标与键盘查看事项；业务查询与最终结果继续显示在消息区。达到上限、超时、用户取消、证据冲突分别记录，并保留适用的已核验结果。

## 核心代码

### 入口与执行

```text Runtime 调用入口
Run API → RunRegistry.register(owner, lifetime_s)
  → AgentExecutor.run(command, context, control, emit)
    → ControlledRun：ExecutionPlan、Verifier、AutonomyBudget、StopPolicy
    → RoutingService.select_route(...) 和逐轮模型调用
    → AgentExecutor._controlled_actions(...) 或普通工具分支
    → RunControl.commit(candidate)
```

## 约束合并

```python 每次运行的轮次与计划约束
plan_prefix = plan_request(command.question)
explicit_plan = plan_prefix is not None or command.constraints.plan == "required"
step_limit = min(self.autonomy_limits.steps, command.constraints.max_steps)
```

运行入口、工具分发和独立核验分别可从 `run_api.py`、`runtime/executor.py`、`runtime/controlled_run.py` 和 `runtime/verifier.py` 跟读。
