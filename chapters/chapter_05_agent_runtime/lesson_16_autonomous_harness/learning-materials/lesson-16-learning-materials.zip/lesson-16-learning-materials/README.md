# 第 16 课学习资料

《企业级Agent工程架构实战营》 · 从 ReAct 到 Plan-and-Execute：建立受控自主执行机制

解压后双击 `TECH_DESIGN.html`，可离线查看目录、搜索正文、放大图表和复制代码。

- [PRD.md](PRD.md) 记录当前需求、业务规则和验收范围。
- [TECH_DESIGN.md](TECH_DESIGN.md) 包含技术正文、Mermaid 图和核心代码附录。
- [TECH_DESIGN.html](TECH_DESIGN.html) 是 Compass Feature 988 的学员阅读版。
