# 第 17 课学习资料

《企业级Agent工程架构实战营》 · 从自主循环到混合编排：构建 Workflow + Agent 执行引擎

解压后双击 `TECH_DESIGN.html` 可离线阅读。图表支持放大，代码支持复制。

- [PRD.md](PRD.md) 记录课内功能、业务规则和验收标准。
- [TECH_DESIGN.md](TECH_DESIGN.md) 收录动态编排、固定提案、周报 Skill、执行节点与核心代码。
- [TECH_DESIGN.html](TECH_DESIGN.html) 是 Compass Feature 987 的学员阅读版。

广告预算提案在本课等待人工决策。持久化审批与恢复由后续课次实现。
